﻿Imports System.Data.OleDb
Imports System.IO
Imports System.Security.Cryptography
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Xml
Imports Amadeus.Script
Imports GDSConector.GDS.Amadeus.Connect
Imports GDSConector.GDS.AmadeusSelco

Public Class Form1

    'Dim con As New HostSession
    Dim con As New WebHostSession
    Dim conn1 As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\refundnotice.xls;Extended Properties=""Excel 8.0;HDR=No;"""
    Dim ConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\Settings.mdb;"
    Dim connect1 As New OleDbConnection(conn1)
    Dim Conn As New OleDbConnection(ConnectionString)
    Dim Dateofissue As String = ""
    Dim tktstatuscodes As String = ""
    Dim fareclasses As String = ""
    Dim PNRret As New PNR
    Dim airl As String = ""
    Dim ttkk As String = ""
    Dim Appname As String = "Refund Notice-1A-Selco"
    Dim refundservice As New RefundService.WebService1
    Dim ServiceToken As String = "GJ%^FA&*@!L&45T34(Hgf^A#I"
    Dim agentname As String = ""
    Dim process_status As String = ""
    Dim up_itin_status As String = ""
    Dim GDS As String = "Amadeus"
    Dim failure_remarks As String = ""
    Dim canc_fee As String = ""
    Dim refund_amt As String = ""
    Dim refund_ref_num As String = ""
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        log("----Refund Notice-Version V1.1-18Mar21----")

        'Dim kk = lic_Decrypt("H1x8NyOpoNMvBNClYvWtNQ==")
        'dim li_from = lic_en

        Dim fromlic As String = ""
        Dim tolic As String = ""

        Dim ds As New DataSet
        ds = refundservice.Check_License(Appname, ServiceToken)
        If ds.Tables(0).Rows.Count > 0 Then
            fromlic = ds.Tables(0).Rows(0)("License_From").ToString.Trim
            tolic = ds.Tables(0).Rows(0)("License_To").ToString.Trim
            Try
                fromlic = lic_Decrypt(fromlic)
                tolic = lic_Decrypt(tolic)
            Catch ex As Exception

            End Try
            agentname = ds.Tables(0).Rows(0)("Agent_Name").ToString.Trim
        End If

        If fromlic <> "" AndAlso tolic <> "" Then
            log("Licence check")
            Dim licary As Array = Nothing
            Dim l_year As String = ""
            Dim l_month As String = ""
            Dim l_date As String = ""
            Dim fromdate As String = ""
            Dim todate As String = ""
            licary = Split(fromlic, ",")

            licary = Split(fromlic, ",")
            l_year = licary(0).ToString.Trim
            l_month = licary(1).ToString.Trim
            l_date = licary(2).ToString.Trim
            fromdate = New DateTime(l_year, l_month, l_date)

            licary = Split(tolic, ",")
            l_year = licary(0).ToString.Trim
            l_month = licary(1).ToString.Trim
            l_date = licary(2).ToString.Trim
            todate = New DateTime(l_year, l_month, l_date)

            If DateTime.Now.Date >= fromdate AndAlso DateTime.Now.Date <= todate Then
                log("Logging in")
            Else
                log("License expired")
                GoTo expired
            End If
        Else
expired:
            MsgBox("License expired.", MsgBoxStyle.OkOnly, "Refund Notice")
            End
        End If

        Dim active_pccs As String = ""
        ds = New DataSet
        ds = refundservice.Check_PCC_License(agentname, GDS, "Enable", ServiceToken)
        If ds.Tables(0).Rows.Count > 0 Then
            For u As Integer = 0 To ds.Tables(0).Rows.Count - 1
                active_pccs = active_pccs & "," & ds.Tables(0).Rows(u)("PCC").ToString.Trim
            Next
        End If
        active_pccs = active_pccs.Trim(",").ToUpper
        log("Active PCCs: " & active_pccs)

        con.Send("QI")
        con.Send("IG")

        If InStr(con.Text, "SIGN IN") Then
            MsgBox("Please Signin Amadeus and try again.", MsgBoxStyle.OkOnly, "Refund Notice")
            End
        End If

        Dim strsql As String = "Select * from [Sheet1$] where F3 = 'open' and F4 = 'Amadeus'"
        Dim dt As New DataTable
        connect1.Open()
        Dim dbCommand As New OleDbCommand(strsql, connect1)
        Dim dataAdapter As New OleDbDataAdapter(dbCommand)
        dataAdapter.Fill(dt)
        connect1.Close()

        Dim PNR As String = ""
        Dim TicketOid As String = ""
        Dim reason As String = ""
        Dim WaiverCode As String = ""
        Dim refstat As Boolean = False
        Dim TripID As String = ""
        Dim ticketno As String = ""
        Dim refund_type As String = ""
        Dateofissue = ""

        For ri As Integer = 0 To dt.Rows.Count - 1

            PNR = ""
            airl = ""
            fareclasses = ""
            ttkk = dt.Rows(ri)(1).ToString.Trim
            TripID = dt.Rows(ri)(0).ToString.Trim
            TicketOid = dt.Rows(ri)(4).ToString.Trim
            WaiverCode = dt.Rows(ri)(24).ToString.Trim.ToUpper
            Dateofissue = ""
            tktstatuscodes = ""
            refstat = False
            process_status = ""
            up_itin_status = ""
            failure_remarks = ""
            canc_fee = ""
            refund_ref_num = ""
            refund_amt = ""
            refund_type = ""

            log("Ticket Number: " & ttkk)
            log("Trip ID: " & TripID)
            log("Ticket Oid: " & TicketOid)
            log("Waiver Code: " & WaiverCode)

            If ttkk = "" Or TicketOid = "" Then
                log("No ticket Number or tkt oid")
                If ttkk = "" Then
                    reason = "Ticket Number Empty"
                ElseIf TicketOid = "" Then
                    reason = "Unable to find ticketing office ID"
                End If
                UpdateFailed(reason, "")
                GoTo nxttkt
            End If

            If InStr(active_pccs, TicketOid) Then
                log("this is valid pcc")
            Else
                GoTo invalidpcc
            End If

            If Regex.IsMatch(ttkk.Replace("-", ""), "^\d+$") Then
                log("Valid ticket")
            Else
                log("Invalid Ticket Number")
                UpdateFailed("Invalid Ticket Number", "")
                GoTo nxttkt
            End If
            ticketno = ttkk

            PNR = GetPNR(ticketno)
            'Dim jumpindone As Boolean = False
            'Dim jin As String = ""
            Dim pret As String = ""

            If PNR = "Failed" Then
                GoTo nxttkt
            End If

            'If PNR = "SecureEtkt" Then
            '    log("Secure eticket")
            '    jin = Jumpin(TicketOid)
            '    If jin = "nxttkt" Then
            '        GoTo nxttkt
            '    End If
            '    jumpindone = True
            '    PNR = GetPNR(ticketno)
            'End If

            If PNR = "" Or PNR = "SecureEtkt" Then
                UpdateFailed("Unable to open the ticket", "")
                GoTo nxttkt
            ElseIf PNR = "Failed" Then
                GoTo nxttkt
            Else
                log("Open coupon check")
                If InStr(tktstatuscodes, "O") Or InStr(tktstatuscodes, "A") Then
                Else
                    log("No open or arpt coupons present")
                    UpdateFailed("No open coupons present", "")
                    GoTo nxttkt
                End If

                log("Other coupon check")
                If tktstatuscodes.Replace("O", "").Replace("A", "").Replace("-", "").Trim = "" Then
                Else
                    log("Other status present")
                    UpdateFailed("Other status present in the ticket", "")
                    GoTo nxttkt
                End If

                log("DOI check")
                If Dateofissue = "" Then
                    log("Unable to find date of issue")
                    UpdateFailed("Unable to find date of issue", "")
                    GoTo nxttkt
                End If

                Dim tv_resp As String = ""
                tv_resp = TravelDate_Validation()
                If tv_resp = "Continue" Then
                    log("Travel date valid")
                Else
                    log("Travel date not valid")
                    UpdateFailed("Travel Date validation failed", "")
                    GoTo nxttkt
                End If


                '    If splitpnr.Length <> 6 Then
                '        log("The split pnr found was invalid.. Failing this trip..")
                '        Return "Failed"
                '    Else
                '        log("Split PNR found")
                '        Return "Success/" & splitpnr
                '    End If
                '    Else
                '    log("No split PNR found.")
                '    Return "NoSplitPNR"
                'End If

                pret = RetrievePNR(PNR)
                If pret = "Failed" Then
                    'UpdateFailed("Unable to Retrieve the PNR", "")
                    'GoTo nxttkt
                    GoTo fullrf
                End If
                PNRret.RetrieveCurrent()


                Dim split_pnr As String = ""
                split_pnr = Find_Split_PNR(PNR)
                If split_pnr = "Failed" Then
                    UpdateFailed("Split PNR found is invalid", "")
                    GoTo nxttkt
                ElseIf split_pnr = "NoSplitPNR" Then
                    log("No split pnr present")
                ElseIf instr(split_pnr, "Success/") Then
                    log("Split PNR found. Failing..")
                    UpdateFailed("Divided PNR found", "")
                    GoTo nxttkt
                End If

            End If

            'If jumpindone = False Then
            '    jin = Jumpin(TicketOid)
            '    If jin = "nxttkt" Then
            '        GoTo nxttkt
            '    End If
            '    pret = RetrievePNR(PNR)
            '    If pret = "Failed" Then
            '        UpdateFailed("Unable to Retrieve the PNR", "")
            '        GoTo nxttkt
            '    End If
            '    PNRret.RetrieveCurrent()
            'End If

            '''''''''''''''''''''''''Corona flow'''''''''''''''''''''''''''''''''
            log("New corona virus flow")
            'Dim histres As String = ""
            If PNRret.AirSegments.Count > 0 Then
                'Dim aircode As String = Get_Airline(ticketno)
                'log("Airline code: " & aircode)
                'If aircode = "AI" Then
                'histres = HistoryCheck(Dateofissue)
                'If histres = "FullRefund" Then
                '    log("UN present. Cancel the itin & punch refund.")
                '    GoTo cancflow
                'Else
                '    log("UN not present. failing.")
                '    GoTo failflow
                'End If
                'Else
                'cancflow:
                Dim itinsts As String = Itinerary_Cancellation(PNR)
                If itinsts = "Failed" Then
                    UpdateFailed("Unable to cancel the itinerary. Refund is not punched.", "")
                    GoTo nxttkt
                End If
                PNRret.RetrieveCurrent()
                If PNRret.AirSegments.Count > 0 Then
                    UpdateFailed("Unable to cancel the itinerary. Refund is not punched.", "")
                    GoTo nxttkt
                Else
                    log("Itin cancellation success1")
                    Updateitincanx("Cancelled")
                End If
                'End If
            Else
                log("No itinerary in PNR1")
                Updateitincanx("No Itinerary")
                'histres = HistoryCheck(Dateofissue) 'here
                'failflow:
                'If histres = "Failed" Then
                '    UpdateFailed("No UN segment present in history", "")
                '    GoTo nxttkt
                'ElseIf histres = "FullRefund" Then
                '    log("Full refund case")
                'ElseIf histres = "Failed1" Then
                '    UpdateFailed("Unable to read the PNR history", "")
                '    GoTo nxttkt
                'End If
            End If
fullrf:
            refund_type = "Full Refund"
            FullRefund(ticketno, WaiverCode)
nxttkt:
            Add_Refund_data(process_status, GDS, TicketOid, WaiverCode, "", "", failure_remarks, canc_fee, refund_amt, refund_ref_num, refund_type, up_itin_status)
invalidpcc:
        Next

        MsgBox("Process Completed", MsgBoxStyle.OkOnly, "Refund Notice")
        End

    End Sub

    Function TravelDate_Validation()

        log("Checking travel date validation")
        Dim start_range As String = "25MAR"
        Dim end_range As String = "24MAY"
        Dim all_travel_dates As String = ""

        all_travel_dates = Find_tkt_traveldates()
        Dim ary As Array = Split(all_travel_dates, ",")
        Dim chk_date As String = ""
        Dim tkt_validity As String = ""
        For i As Integer = 0 To ary.Length - 1
            chk_date = ary(i).ToString
            log("Dep date to check: " & chk_date)
            If (Convert.ToDateTime(chk_date) >= Convert.ToDateTime(start_range)) AndAlso (Convert.ToDateTime(chk_date) <= Convert.ToDateTime(end_range)) Then
                tkt_validity = tkt_validity & "," & "Valid"
            Else
                tkt_validity = tkt_validity & "," & "Invalid"
                Exit For
            End If
        Next
        If InStr(tkt_validity, "Invalid") Then
            log("Invalid present")
        Else
            Return "Continue"
        End If
        Return "Failed"

    End Function

    Function Find_tkt_traveldates()

        log("Find travel dates")
        Dim all_travel_dates As String = ""
        For ti As Integer = 3 To con.ResponseLines.Count - 1
            If InStr(con.ResponseLines(ti).ToString.Trim, "DOI-") Then
            ElseIf IsNumeric(con.ResponseLines(ti).ToString.Trim.Substring(0, 1)) AndAlso InStr(con.ResponseLines(ti).ToString, ".") = False Then
                If InStr(con.ResponseLines(ti).ToString, "ARNK") Then
                Else
                    all_travel_dates = all_travel_dates & "," & con.ResponseLines(ti).ToString.Substring(19, 5).Trim
                End If
            End If
        Next
        all_travel_dates = all_travel_dates.Trim(",")
        log("Ticket dep dates: " & all_travel_dates)
        Return all_travel_dates

    End Function

    Private Function Get_Airline(ByVal ticketno) ' GET AIRLINE

        log("Inside Airline function")

        If Mid$(ticketno, 1, 3) = "589" Then
            airl = "9W"
        ElseIf Mid$(ticketno, 1, 3) = "098" Then
            airl = "AI"
        ElseIf Mid$(ticketno, 1, 3) = "228" Then
            airl = "UK"
        End If

        log("Airline: " & airl)
        Return airl

    End Function

    Function Itinerary_Cancellation(ByVal PNR As String)

        log("Itin cancellation")
        con.Send("XI")
        log("XI")
        log(con.Text)

        If InStr(con.Text, PNR) Then
            con.Send("RFRFDTOOL")
            log("RFRFDTOOL")
            log(con.Text)

            con.Send("ER")
            log("ER")
            log("ER")
            log(con.Text)
            If InStr(con.Text, PNR) Then
                log("Itin canc success-1")
                Return ""
            Else
                Return "Failed"
            End If
        Else
            con.Send("IG")
            Return "Failed"
        End If
    End Function

    Function RetrievePNR(ByVal GDSPNR As String) As String

        con.Send("RT" & GDSPNR)
        log("RT" & GDSPNR)
        log(con.Text)

        If con.ResponseLines.Count > 4 Then
        Else
            Return "Failed"
        End If
        Return "Success"
    End Function

    Function Find_Split_PNR(ByVal GDSPNR As String)

        log("Find Split PNR")
        'If GDSPNR <> "" Then
        '    log("PNR Present...")
        '    RetrievePNR(GDSPNR)
        'End If

        Dim spelement As String = ""
        Dim splitpnr As String = ""
        spelement = con.ResponseLines(con.ResponseLines.Count - 1).ToString.Trim
        log("SP element1: " & spelement)

        If spelement.Trim = "" Or spelement = ">" Then
            spelement = con.ResponseLines(con.ResponseLines.Count - 2).ToString.Trim
        End If
        log("SP element2: " & spelement)

        If spelement.Trim.StartsWith("* SP") Then
            Dim spary As Array = Split(spelement, "-")
            splitpnr = spary(1).ToString.Trim
            log("Taken split PNR: " & splitpnr)

            If splitpnr.Length <> 6 Then
                log("The split pnr found was invalid.. Failing this trip..")
                Return "Failed"
            Else
                log("Split PNR found")
                Return "Success/" & splitpnr
            End If
        Else
            log("No split PNR found.")
            Return "NoSplitPNR"
        End If

    End Function

    Private Function FullRefund(ByVal ticketno As String, ByVal WaiverCode As String)

        log("Full refund flow")

        Dim cancelfee As String = ""
        Dim refundamt As String = ""
        Dim refundtype As String = "Full Refund"

        con.Send("TRF" & ticketno)
        log("TRF" & ticketno)
        log(con.Text)

        If InStr(con.Text, "REFUND RECORD") Then
        Else
            UpdateFailed(con.ResponseLines(0).ToString.Trim, refundtype)
            Return ""
        End If

        If WaiverCode <> "" Then
            log("Waiver present-Usual flow")
            con.Send("TRFU/WA" & WaiverCode)

            log("TRFU/WA" & WaiverCode)
            log(con.Text)

            If InStr(con.Text, "REFUND RECORD") Then
            Else
                UpdateFailed("Waiver updation failed", refundtype)
                Return ""
            End If
        End If

        con.Send("TRFU/CP0A")
        log("TRFU/CP0A")
        log(con.Text)

        Dim taxname As String = ""
        Dim taxstr As String = ""
        Dim isStart As Boolean = False
        Dim taxary As Array = Nothing
        Dim non_refundable_taxes As String = "" 'E3,N7
        Dim delete_tax_lines As String = ""
        Dim delete_tax_amts As String = ""
        Dim taxline As String = ""
        Dim taxamt As String = "0"
        Dim canc_penalty As Integer = 0
        Dim range1 As String = "31MAR20"

        If Convert.ToDateTime(Dateofissue) <= Convert.ToDateTime(range1) Then
            log("Ticket issued on/before 31Mar20. K3 is non-refundable")
            non_refundable_taxes = "K3"
        End If
        log("Final non refund tax list: " & non_refundable_taxes)


        If non_refundable_taxes <> "" Then
            con.Send("TRFT")
            log("TRFT")
            log(con.Text)

            For ci As Integer = 0 To con.ResponseLines.Count - 1
                taxname = ""
                taxstr = con.ResponseLines(ci).ToString.Trim
                If con.ResponseLines(ci).ToString.Trim.Contains("----------------------------------") Then
                    isStart = True
                Else
                    If isStart = True And con.ResponseLines(ci).ToString.Trim <> "" Then
                        log("Tax str: " & taxstr)
                        If InStr(taxstr, " ") Then
                            taxary = Split(taxstr.Trim, " ")
                            taxname = taxary(taxary.Length - 1)
                            taxline = ""
                            taxamt = ""
                            log("Tax name: " & taxname)
                            If InStr(non_refundable_taxes, taxname) Then
                                taxline = con.ResponseLines(ci).ToString.Trim.Substring(0, 2).Replace("T", "")
                                taxamt = taxary(taxary.Length - 2).ToString.Trim
                                delete_tax_lines = delete_tax_lines & "," & taxline
                                delete_tax_amts = delete_tax_amts & "," & taxamt
                            End If
                        End If
                    End If
                End If
            Next

            delete_tax_amts = delete_tax_amts.Trim(",")
            delete_tax_lines = delete_tax_lines.Trim(",")
        End If

        log("Delete tax line: " & delete_tax_lines)
        log("Delete tax amts: " & delete_tax_amts)

        If delete_tax_lines <> "" Then
            log("Deleting non refundable taxes")
            Dim taxdelete_entry As String = ""
            Dim tary As Array = Split(delete_tax_lines, ",")
            For u As Integer = 0 To tary.Length - 1
                taxdelete_entry = taxdelete_entry & "/" & "TX" & tary(u).ToString
            Next
            taxdelete_entry = taxdelete_entry.Trim("/")
            taxdelete_entry = "TRFU/" & taxdelete_entry

            con.Send(taxdelete_entry)
            log(taxdelete_entry)
            log(con.Text)

            tary = Nothing
            tary = Split(delete_tax_amts, ",")
            For u As Integer = 0 To tary.Length - 1
                canc_penalty = canc_penalty + CInt(tary(u).ToString)
            Next
            log("canc Penalty: " & canc_penalty)
        End If

        con.Send("TRF")
        log("TRF")
        log(con.Text)

        If InStr(con.Text, "CANX FEE") Then
            For i As Integer = 0 To con.ResponseLines.Count - 1
                If InStr(con.ResponseLines(i).ToString, "CANX FEE") Then
                    cancelfee = con.ResponseLines(i).ToString.Trim.Substring(2).Replace("CANX FEE", "").Trim
                ElseIf InStr(con.ResponseLines(i).ToString, "REFUND TOTAL") Then
                    refundamt = con.ResponseLines(i).ToString.Trim.Replace("REFUND TOTAL", "").Trim
                    Exit For
                End If
            Next
        End If
        log("Cancel Fee: " & cancelfee)
        log("Refund amt: " & refundamt)

        con.Send("TRFU/NF")
        log("TRFU/NF")
        log(con.Text)

        con.Send("TRFU/RM FULL REFUND AS PER SC VERDICT")
        log("TRFU/RM FULL REFUND AS PER SC VERDICT")
        log(con.Text)

        con.Send("TRFP")
        log("TRFP")
        log(con.Text)

        If InStr(con.Text, "OK - REFUND PROCESSED") Then
            log("Refund Success")
            Dim refno As String = Mid$(con.Text, InStr(con.Text, "SAC-"), 19).Trim
            If canc_penalty = 0 Then
                Dim cancelfeeAry As Array = cancelfee.Split(" ")
                UpdateClosed(refundamt, cancelfeeAry(0).ToString, refno, refundtype)
            Else
                log("Updating e3 tax")
                UpdateClosed(refundamt, canc_penalty, refno, refundtype)
            End If
            Return "Success"
        Else
            log("Refund failed")
            UpdateFailed(con.ResponseLines(0).ToString.Trim, refundtype)
        End If
        Return ""
    End Function

    Sub Add_Refund_data(ByVal process_status As String, ByVal GDS As String, ByVal Ticketing_PCC As String, ByVal Waiver_Code As String, ByVal Is_Cancellation_Needed As String, ByVal Agent_Cancellation_Penalty As String, ByVal Remarks As String, ByVal Cancellation_Charges As String, ByVal Refund_Amount As String, ByVal Reference_Number As String, ByVal Refund_Type As String, ByVal Itinerary_Status As String)
        log("Data insertion")
        Dim timestamp As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        Dim datares As String = refundservice.Set_Agent_Refund_Details(ttkk, process_status, GDS, Ticketing_PCC, Waiver_Code, Is_Cancellation_Needed, Agent_Cancellation_Penalty, Remarks, Cancellation_Charges, Refund_Amount, Reference_Number, timestamp, Refund_Type, Itinerary_Status, timestamp, agentname, ServiceToken)
        log("Data Res: " & datares)
    End Sub

    Public Function lic_Decrypt(ByVal cipherText As String) As String

        Dim passPhrase As String = "licpassphrase"
        Dim saltValue As String = "LicenseDate"
        Dim hashAlgorithm As String = "SHA1"

        Dim passwordIterations As Integer = 2
        Dim initVector As String = "@1B2c3D4e5F6g7H8"
        Dim keySize As Integer = 256
        Dim initVectorBytes As Byte() = Encoding.ASCII.GetBytes(initVector)
        Dim saltValueBytes As Byte() = Encoding.ASCII.GetBytes(saltValue)
        Dim cipherTextBytes As Byte() = Convert.FromBase64String(cipherText)
        Dim password As New PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations)
        Dim keyBytes As Byte() = password.GetBytes(keySize \ 8)
        Dim symmetricKey As New RijndaelManaged()
        symmetricKey.Mode = CipherMode.CBC
        Dim decryptor As ICryptoTransform = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes)

        Dim memoryStream As New MemoryStream(cipherTextBytes)
        Dim cryptoStream As New CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read)
        Dim plainTextBytes As Byte() = New Byte(cipherTextBytes.Length - 1) {}
        Dim decryptedByteCount As Integer = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length)
        memoryStream.Close()
        cryptoStream.Close()

        Dim plainText As String = Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount)
        Return plainText
    End Function

    Function HistoryCheck(ByVal DOI As String)

        log("History check")
        Dim amadeushistory As New XmlDocument
        Dim xmldata As String = CreateHistoryxml()
        If xmldata = "NextPNR" Then
            log("Going to next PNR")
            Return "Failed1"
        End If

        Dim idstring As String = ""
        Dim xs_depdate As String = ""
        Dim xs_deptime As String = ""
        Dim actionitems As XmlNodeList
        Dim cancelsegpresent As Boolean = False
        Dim aircancsegpresent As Boolean = False
        Dim status As String = ""

        amadeushistory.LoadXml(xmldata)
        actionitems = amadeushistory.SelectNodes("//action")

        Try

            For Each action As XmlNode In actionitems
                If action.SelectNodes("actionitem").Count > 0 Then
                    Dim actionitems1 As XmlNodeList
                    actionitems1 = action.SelectNodes("actionitem")
                    For Each node As XmlNode In actionitems1
                        If node.ChildNodes.Count > 1 Then
                            If InStr(node("status").InnerText.ToString, "UN") Then
                                log("UN present..")
                                Return "FullRefund"
                            End If
                        End If
                    Next
                End If
            Next
            Return "Failed"
        Catch ex As Exception
            log("Reading canc details: " & ex.Message.ToString)
            Return "Failed1"
        End Try

    End Function

    Private Function GetPNR(ByVal ticketno As String)

        log("Get PNR function")
        Dim apnr As String = ""
        Dateofissue = ""
        con.Send("TWD/TKT" & ticketno)

        log("TWD/TKT" & ticketno)
        log(con.Text)

        If InStr(con.Text, "SECURED ETKT RECORD(S)") Then
            Return "SecureEtkt"
        ElseIf InStr(con.Text, "DOCUMENT NUMBER NOT ELECTRONIC") Then
            UpdateFailed("DOCUMENT NUMBER NOT ELECTRONIC", "")
            Return "Failed"
        ElseIf InStr(con.Text, "TICKET NUMBER NOT FOUND") Then
            UpdateFailed("TICKET NUMBER NOT FOUND", "")
            Return "Failed"
        ElseIf InStr(con.Text, "INVALID REQUESTOR IDENTIFICATION") Then
            UpdateFailed("INVALID REQUESTOR IDENTIFICATION", "")
            Return "Failed"
        End If
        apnr = Mid$(con.Text, InStr(con.Text, "1A  LOC") + 8, 6)
        log("PNR found: " & apnr)
        Find_FareClasses()
        Find_DOI()
        Check_Status()
        Return apnr

    End Function

    Function Find_FareClasses()
        log("Finding fare classes")
        fareclasses = ""
        For ti As Integer = 0 To con.ResponseLines.Count - 1
            If con.ResponseLines(ti).Substring(8, 2).ToString.Trim = "" Then
                Exit For
            End If
            If InStr(con.ResponseLines(ti).ToString.Trim, "DOI-") Then
            ElseIf IsNumeric(con.ResponseLines(ti).ToString.Trim.Substring(0, 1)) AndAlso InStr(con.ResponseLines(ti).ToString, ".") = False Then
                If InStr(con.ResponseLines(ti).ToString, "ARNK") Then
                Else
                    fareclasses = fareclasses & "," & con.ResponseLines(ti).ToString.Substring(32, 1)
                End If
            End If
        Next
        fareclasses = fareclasses.Trim(",")
        Return fareclasses
    End Function

    Function Find_DOI()
        For ti As Integer = 0 To con.ResponseLines.Count - 1
            If InStr(con.ResponseLines(ti).ToString.Trim, "DOI-") Then
                Dim doiary As Array = Split(con.ResponseLines(ti).ToString.Trim, "DOI-")
                Dateofissue = doiary(1).ToString.Trim.Substring(0, 7)
                Exit For
            End If
        Next
        log("Date of issue: " & Dateofissue)
        Return Dateofissue
    End Function

    Function Jumpin(ByVal TicketOid As String)

        Dim son As String = ""
        Dim pwfd As String = ""
        Dim reason As String = ""
        Dim jdpcc As String = ""

        con.Send("IG")
        log("IG")
        log(con.Text)

        con.Send("JD")
        log("JD")
        log(con.Text)

        Try
            For h As Integer = 0 To con.ResponseLines.Count - 1
                If InStr(con.ResponseLines(h).ToString, "REMOTE OFFICE MODE") Then
                Else
                    If con.ResponseLines(h).ToString.Trim <> "" Then
                        If IsNumeric(con.ResponseLines(h).ToString.Trim.Substring(0, 2)) Then
                            Dim jdary As Array = Split(con.ResponseLines(h).ToString, "         ")
                            jdpcc = jdary(1).ToString.Trim
                            Exit For
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            log("Issue with JD PCC1: " & ex.Message.ToString)
        End Try
        log("JD PCC: " & jdpcc)

        If jdpcc = TicketOid Then
            log("Jumpin not required.")
            Return ""
        End If

        son = DataRet("Sign_on", TicketOid)
        pwfd = DataRet("Pwd", TicketOid)
        If son = "" Or pwfd = "" Then
            log("No jumpin credentials")
            GoTo upfail
        End If
        son = son & "-" & DataRet("Pwd", TicketOid)
        con.Send("JUM/O-" & TicketOid & "/" & son)
        log("JUM/O-" & TicketOid & "/" & son)
        log(con.Text)

        If (InStr(con.Text, "CHECK FORMAT") AndAlso pwfd.Trim = "") Or con.Text = "" Then
upfail:
            reason = "Credentails not Available in the settings for the Ticket OfficeID " & TicketOid
            UpdateFailed(reason, "")
            Return "nxttkt"
        ElseIf InStr(con.Text, "INVALID SIGN") Then
            reason = "INVALID SIGN for the Ticket OfficeID " & TicketOid
            UpdateFailed(reason, "")
            Return "nxttkt"
        End If

        If InStr(con.Text, "OFFICE ID MATCHES INPUT ENTRY OFFICE") Then
            con.Send("JUO-" & pwfd)
            If InStr(con.Text, "BOM3C25JD") Or InStr(con.Text, "NO REMOTE OFFICE LOGON") Then

            End If
        End If

        If InStr(con.Text, "SIGN COMPLETE") Or InStr(con.Text, "OFFICE ID MATCHES INPUT ENTRY OFFICE") Then
            log("Sign in complete")
        Else
            reason = "Unable to Signon for the Ticket OfficeID " & TicketOid.Trim
            UpdateFailed(reason, "")
            Return "nxttkt"
        End If

        Return ""
    End Function

    Private Function DataRet(ByVal field As String, ByVal value As String) As String

        Dim ConnectionString12 As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Settings.mdb"
        Dim Connec As New OleDbConnection(ConnectionString12)
        Dim str1 As String
        Dim cmd As OleDbCommand

        Connec.Open()
        Dim dr As OleDbDataReader
        str1 = "select " & field & " from credential where [Office_ID_PCC]=" & "'" & value & "'"
        cmd = New OleDbCommand(str1, Connec)
        dr = cmd.ExecuteReader
        Dim val As String = ""
        While dr.Read
            val = dr(0).ToString()
        End While
        Connec.Close()
        Return val
    End Function

    Function Check_Status()

        log("Checking the status")
        Dim stat As String = ""
        Dim dummyst As String = ""
        tktstatuscodes = ""

        For i As Integer = 1 To con.ResponseLines.Count - 1
            If InStr(con.ResponseLines(i).ToString, "  ST  ") Then
                Do Until con.ResponseLines(i).Trim.Length < 10
                    'stat = stat & "-" & Mid$(con.ResponseLines(i + 1), 46, 4).Trim
                    dummyst = ""
                    dummyst = Mid$(con.ResponseLines(i + 1), 46, 4).Trim
                    If dummyst.Length > 1 Then
                        dummyst = dummyst.Substring(0, 1)
                    End If
                    stat = stat & "-" & dummyst
                    i = i + 1
                Loop
            End If
        Next
        stat = stat.Trim("-")
        log("All ticket status: " & stat)
        tktstatuscodes = stat
        Return tktstatuscodes

    End Function

    Public Function CreateHistoryxml() As String

        con.GetAllLines = True
        con.Send("RHA")

        If con.ResponseLines.Count > 3 Then
        Else
            con.Send("RPP/RHA")
            If InStr(con.Text, "NO PNR HISTORY IS AVAILABLE") Then
                Return "NextPNR"
            End If
        End If

        log("History: " & con.Text)

        Dim j As Integer = 0
        Dim sprp As String = ""
        Dim spr As String = ""
        Dim sld As String = ""
        Dim seq As Integer = 0
        Dim k As Integer = 0

        'For k = 0 To con.ResponseLines.Count - 1
        '    If InStr(con.ResponseLines(k).ToString, "RP/") Then
        '        bookingdt = Mid$(con.ResponseLines(k + 1).ToString.Trim, con.ResponseLines(k + 1).ToString.Trim.Length - 6)
        '        Exit For
        '    End If
        'Next

        For j = 0 To con.ResponseLines.Count - 1

            If InStr(con.ResponseLines(j).ToString, "RF-") Then

                sld = ""
                sld = Trim(con.ResponseLines(j).ToString)
                If con.ResponseLines(j + 1).ToString.Trim = ")>" Then
                    j = j + 1
                End If
                Do While Mid$(con.ResponseLines(j + 1).ToString, 1, 6) = "      "
                    sld = sld & Trim(con.ResponseLines(j + 1).ToString)
                    j = j + 1
                Loop
                seq = seq + 1
                sprp = sprp & "<action id=""" & sld & """ seq=""" & seq & """>" & spr & "</action>"
                spr = ""

            Else

                Dim add As Array = Trim(con.ResponseLines(j).ToString).Split(" ")
                Dim apr As String = con.ResponseLines(j).ToString

                If InStr(apr, " AS/") Or InStr(apr, " CS/") Or InStr(apr, " OS/") Or InStr(apr, " TC/") Or InStr(apr, " XS/") Then

                    Dim dpr As String = ""
                    dpr = dpr & "<Type>AIRSEG</Type>"
                    dpr = dpr & "<Rfno>" & add(0) & "</Rfno>"

                    If add(1).ToString.Length > 5 Then

                        dpr = dpr & "<aacode>" & Mid$(add(1), 1, 2) & "</aacode>"
                        dpr = dpr & "<Airline>" & Mid$(add(1), 4, 2) & "</Airline>"
                        dpr = dpr & "<flightno>" & Mid$(add(1), 6, add(1).ToString.Length) & "</flightno>"
                        dpr = dpr & "<class>" & add(2) & "</class>"
                        dpr = dpr & "<date>" & add(3) & "</date>"
                        dpr = dpr & "<dummy>" & add(4) & "</dummy>"
                        dpr = dpr & "<origin>" & Mid$(add(5), 1, 3) & "</origin>"
                        dpr = dpr & "<dest>" & Mid$(add(5), 4, 6) & "</dest>"
                        dpr = dpr & "<status>" & add(6) & "</status>"
                        dpr = dpr & "<dep>" & add(7) & "</dep>"
                        dpr = dpr & "<arr>" & add(8) & "</arr>"

                        If Mid$(add(1), 1, 2) = "TC" Then
                            If add.Length > 10 Then
                                dpr = dpr & "<olddep>" & add(9) & "</olddep>"
                                dpr = dpr & "<oldarr>" & add(10) & "</oldarr>"
                            Else
                                dpr = dpr & "<olddep></olddep>"
                                dpr = dpr & "<oldarr></oldarr>"
                            End If
                        End If
                        spr = spr & "<actionitem>" & dpr & "</actionitem>"

                    Else

                        dpr = dpr & "<aacode>" & Mid$(add(1), 1, 2) & "</aacode>"
                        dpr = dpr & "<Airline>" & Mid$(add(1), 4, 2) & "</Airline>"
                        dpr = dpr & "<flightno>" & add(2) & "</flightno>"
                        dpr = dpr & "<class>" & add(3) & "</class>"
                        dpr = dpr & "<date>" & add(4) & "</date>"
                        dpr = dpr & "<dummy>" & add(5) & "</dummy>"
                        dpr = dpr & "<origin>" & Mid$(add(6), 1, 3) & "</origin>"
                        dpr = dpr & "<dest>" & Mid$(add(6), 4, 6) & "</dest>"
                        dpr = dpr & "<status>" & add(7) & "</status>"
                        dpr = dpr & "<dep>" & add(8) & "</dep>"
                        dpr = dpr & "<arr>" & add(9) & "</arr>"

                        If Mid$(add(1), 1, 2) = "TC" Then

                            If add.Length > 11 Then
                                dpr = dpr & "<olddep>" & add(10) & "</olddep>"
                                dpr = dpr & "<oldarr>" & add(11) & "</oldarr>"
                            Else
                                dpr = dpr & "<olddep></olddep>"
                                dpr = dpr & "<oldarr></oldarr>"
                            End If

                        End If
                        spr = spr & "<actionitem>" & dpr & "</actionitem>"

                    End If

                Else
                    spr = spr & "<actionitem>*****" & Trim(con.ResponseLines(j).ToString) & "</actionitem>"
                End If

            End If

        Next

        spr = "<xmlout>" & sprp & "</xmlout>"
        Return spr

    End Function

    Function UpdateFailed(ByVal RemarkText As String, ByVal TypeofRefund As String) As String

        log("Update Fun-Failed")
        process_status = "Failed"
        Dim affcount As Integer = 0
        Dim strSQL2 As String = ""
        Dim dbCommand2 As New OleDbCommand

        Try
            If connect1.State = ConnectionState.Closed Then
                connect1.Open()
            End If
            strSQL2 = "Update [Sheet1$] set F3 = 'Failed', F18 = '" & RemarkText & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2='" & ttkk & "' and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, connect1)
            affcount = dbCommand2.ExecuteNonQuery()
            connect1.Close()
            Try
                If affcount = 0 Then
                    If connect1.State = ConnectionState.Closed Then
                        connect1.Open()
                    End If
                    strSQL2 = "Update [Sheet1$] set F3 = 'Failed', F18 = '" & RemarkText & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2=" & ttkk & " and F3='open'"
                    log(strSQL2)
                    dbCommand2 = New OleDbCommand(strSQL2, connect1)
                    dbCommand2.ExecuteNonQuery()
                    connect1.Close()
                End If
            Catch ex As Exception

            End Try
            Return "Failed"
        Catch ex As Exception
            If connect1.State = ConnectionState.Closed Then
                connect1.Open()
            End If
            strSQL2 = "Update [Sheet1$] set F3 = 'Failed', F18 = '" & RemarkText & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2=" & ttkk & " and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, connect1)
            dbCommand2.ExecuteNonQuery()
            connect1.Close()
            Return "Failed"
        End Try

    End Function

    Function UpdateClosed(ByVal RefundAmount As String, ByVal CancelfeeAmt As String, ByVal ReferenceNum As String, ByVal TypeofRefund As String) As String

        log("Update Fun-Closed")
        process_status = "Closed"
        canc_fee = CancelfeeAmt
        refund_amt = RefundAmount
        refund_ref_num = ReferenceNum

        Dim affcount As Integer = 0
        Dim strSQL2 As String = ""
        Dim dbCommand2 As New OleDbCommand

        Try
            If connect1.State = ConnectionState.Closed Then
                connect1.Open()
            End If
            strSQL2 = "Update [Sheet1$] set F3 = 'Closed', F19 = '" & CancelfeeAmt & "', F20 = '" & RefundAmount & "', F21 = '" & ReferenceNum & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2='" & ttkk & "' and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, connect1)
            affcount = dbCommand2.ExecuteNonQuery()
            connect1.Close()
            Try
                If affcount = 0 Then
                    If connect1.State = ConnectionState.Closed Then
                        connect1.Open()
                    End If
                    strSQL2 = "Update [Sheet1$] set F3 = 'Closed', F19 = '" & CancelfeeAmt & "', F20 = '" & RefundAmount & "', F21 = '" & ReferenceNum & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2=" & ttkk & " and F3='open'"
                    log(strSQL2)
                    dbCommand2 = New OleDbCommand(strSQL2, connect1)
                    dbCommand2.ExecuteNonQuery()
                    connect1.Close()
                End If
            Catch ex As Exception

            End Try
            Return "Success"
        Catch ex As Exception
            If connect1.State = ConnectionState.Closed Then
                connect1.Open()
            End If
            strSQL2 = "Update [Sheet1$] set F3 = 'Closed', F19 = '" & CancelfeeAmt & "', F20 = '" & RefundAmount & "', F21 = '" & ReferenceNum & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2=" & ttkk & " and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, connect1)
            dbCommand2.ExecuteNonQuery()
            connect1.Close()
            Return "Success"
        End Try

    End Function

    Function Updateitincanx(ByVal itin_status As String) As String

        log("Update Fun-Failed")
        up_itin_status = itin_status
        Dim affcount As Integer = 0
        Dim strSQL2 As String = ""
        Dim dbCommand2 As New OleDbCommand

        Try
            If connect1.State = ConnectionState.Closed Then
                connect1.Open()
            End If
            strSQL2 = "Update [Sheet1$] set F26 = '" & itin_status & "' where F2='" & ttkk & "' and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, connect1)
            affcount = dbCommand2.ExecuteNonQuery()
            connect1.Close()
            Try
                If affcount = 0 Then
                    If connect1.State = ConnectionState.Closed Then
                        connect1.Open()
                    End If
                    strSQL2 = "Update [Sheet1$] set F26 = 'Cancelled' where F2='" & ttkk & "' and F3='open'"
                    log(strSQL2)
                    dbCommand2 = New OleDbCommand(strSQL2, connect1)
                    dbCommand2.ExecuteNonQuery()
                    connect1.Close()
                End If
            Catch ex As Exception

            End Try
            Return "Failed"
        Catch ex As Exception
            If connect1.State = ConnectionState.Closed Then
                connect1.Open()
            End If
            strSQL2 = "Update [Sheet1$] set F26 = 'Cancelled' where F2='" & ttkk & "' and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, connect1)
            dbCommand2.ExecuteNonQuery()
            connect1.Close()
            Return "Failed"
        End Try

    End Function

    Public Sub log(ByVal a As String)

        Try
            Dim sb As New System.Text.StringBuilder()
            Dim d As String = Now.Date
            Dim s As String = d.Replace("/", "-")
            Dim text As String = ""
            Dim filename As String = Application.StartupPath & "\Logs\" & s & ".log"
            Dim objwriter As IO.StreamWriter
            If System.IO.File.Exists(filename) = True Then
                objwriter = New IO.StreamWriter(filename, True)
                text = log_Encrypt(Now.DayOfWeek.ToString & "-" & Now.ToString & ":" & a)
                objwriter.WriteLine("^^^^^^^^^^^^^^^^^^^^^")
                objwriter.WriteLine(text)
                objwriter.WriteLine("^^^^^^^^^^^^^^^^^^^^^")
                objwriter.Close()
            Else
                File.Create(filename).Dispose()
                objwriter = New StreamWriter(filename, True)
                text = log_Encrypt(Now.DayOfWeek.ToString & "-" & Now.ToString & ":" & a)
                objwriter.WriteLine("^^^^^^^^^^^^^^^^^^^^^")
                objwriter.Write(text)
                objwriter.WriteLine("^^^^^^^^^^^^^^^^^^^^^")
                objwriter.Write(vbNewLine)
                objwriter.Close()
            End If
        Catch ex As Exception

        End Try

    End Sub

    Public Function log_Encrypt(ByVal plainText As String) As String

        Dim passPhrase As String = "LogPassPhrase"
        Dim saltValue As String = "Log"
        Dim hashAlgorithm As String = "SHA1"
        Dim passwordIterations As Integer = 2
        Dim initVector As String = "@1B2c3D4e5F6g7H8"
        Dim keySize As Integer = 256
        Dim initVectorBytes As Byte() = Encoding.ASCII.GetBytes(initVector)
        Dim saltValueBytes As Byte() = Encoding.ASCII.GetBytes(saltValue)
        Dim plainTextBytes As Byte() = Encoding.UTF8.GetBytes(plainText)
        Dim password As New PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations)
        Dim keyBytes As Byte() = password.GetBytes(keySize \ 8)
        Dim symmetricKey As New RijndaelManaged()
        symmetricKey.Mode = CipherMode.CBC
        Dim encryptor As ICryptoTransform = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes)
        Dim memoryStream As New MemoryStream()
        Dim cryptoStream As New CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write)
        cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length)
        cryptoStream.FlushFinalBlock()
        Dim cipherTextBytes As Byte() = memoryStream.ToArray()
        memoryStream.Close()
        cryptoStream.Close()
        Dim cipherText As String = Convert.ToBase64String(cipherTextBytes)
        Return cipherText

    End Function
End Class
