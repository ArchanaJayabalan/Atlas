﻿Imports System.Data.OleDb
Imports System.IO
Imports System.Security.Cryptography
Imports System.Text
Imports System.Xml

Public Class Form1

    Dim excelstr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\refundnotice.xls;Extended Properties=""Excel 8.0;HDR=No;"""
    'Dim mdbstr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\Settings.mdb;"
    Dim excelconn As New OleDbConnection(excelstr)
    'Dim conn As New OleDbConnection(mdbstr)
    Dim con As New HostAccess.TerminalEmulation
    Dim ttkk As String = ""
    Dim Appname As String = "Refund Notice-1G"
    Dim refundservice As New RefundService.WebService1 'http://reshandthoshcloud.com/rfrnt/webservice1.asmx
    Dim ServiceToken As String = "GJ%^FA&*@!L&45T34(Hgf^A#I"
    Dim agentname As String = ""
    Dim GDS As String = "Galileo"
    Dim process_st As String = ""
    Dim up_itin_status As String = ""
    Dim failure_remarks As String = ""
    Dim cdt As New DataTable

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Dim card_no1 As String = "AX67898909871005"
        'Dim last_4_digit1 As String = card_no1.Substring(card_no1.Length - 4)


        log("----Refund Notice-Version V1.6-24Mar2021----")

        'ReadTicketDetails()
        PurgePNRRetrieval()

        'Dim jj = lic_Encrypt("2021,04,20")

        'Purged_PNR_Check("30MAR20", "")

        Dim fromlic As String = ""
        Dim tolic As String = ""

        Dim ds As New DataSet
        ds = refundservice.Check_License(Appname, ServiceToken)
        If ds.Tables(0).Rows.Count > 0 Then
            fromlic = ds.Tables(0).Rows(0)("License_From").ToString.Trim
            tolic = ds.Tables(0).Rows(0)("License_To").ToString.Trim
            fromlic = lic_Decrypt(fromlic)
            tolic = lic_Decrypt(tolic)
            agentname = ds.Tables(0).Rows(0)("Agent_Name").ToString.Trim
            log("Agent Name: " & agentname)
        End If

        If fromlic <> "" AndAlso tolic <> "" Then
            log("Licence check")
            Dim licary As Array = Nothing
            Dim l_year As String = ""
            Dim l_month As String = ""
            Dim l_date As String = ""
            Dim fromdate As String = ""
            Dim todate As String = ""
            licary = Split(fromlic, ",")

            licary = Split(fromlic, ",")
            l_year = licary(0).ToString.Trim
            l_month = licary(1).ToString.Trim
            l_date = licary(2).ToString.Trim
            fromdate = New DateTime(l_year, l_month, l_date)

            licary = Split(tolic, ",")
            l_year = licary(0).ToString.Trim
            l_month = licary(1).ToString.Trim
            l_date = licary(2).ToString.Trim
            todate = New DateTime(l_year, l_month, l_date)

            If DateTime.Now.Date >= fromdate AndAlso DateTime.Now.Date <= todate Then
                log("Logging in")
            Else
                log("License expired")
                GoTo expired
            End If
        Else
expired:
            MsgBox("License expired", MsgBoxStyle.OkOnly, "Refund Notice")
            End
        End If

        Dim active_pccs As String = ""
        ds = New DataSet
        ds = refundservice.Check_PCC_License(agentname, GDS, "Enable", ServiceToken)
        If ds.Tables(0).Rows.Count > 0 Then
            For u As Integer = 0 To ds.Tables(0).Rows.Count - 1
                active_pccs = active_pccs & "," & ds.Tables(0).Rows(u)("PCC").ToString.Trim
            Next
        End If
        active_pccs = active_pccs.Trim(",").ToUpper
        log("Active PCCs: " & active_pccs)

        ds = New DataSet
        ds = refundservice.Get_Credit_Card_Details(agentname, ServiceToken)
        cdt = ds.Tables(0)

        Dim GDSResp = GDSEntry("I")
        GDSEntry("QXI")
        If GDSResp.Contains("SIGN IN") Then
            MsgBox("Please sign in into Galileo and try again.", MsgBoxStyle.OkOnly, "Refund Notice")
            End
        End If

        Dim strsql As String = "Select * from [Sheet1$] where F3 = 'Open' and F4 = 'Galileo'"
        Dim dt As New DataTable
        excelconn.Open()
        Dim dbCommand As New OleDbCommand(strsql, excelconn)
        Dim dataAdapter As New OleDbDataAdapter(dbCommand)
        dataAdapter.Fill(dt)
        excelconn.Close()
        log("No of tickets: " & dt.Rows.Count)

        Dim PNR As String = ""
        Dim TicketOid As String = ""
        Dim WaiverCode As String = ""
        Dim TripID As String = ""
        Dim TicketNo As String = ""
        Dim reason As String = ""
        Dim emures As String = ""
        Dim GDSPNR As String = ""
        Dim pnr_sts As String = ""
        Dim tktResp As String = ""
        Dim cancelitin As String = ""
        Dim doi As String = ""
        Dim refund_resp As String = ""
        Dim tkt_status As String = ""
        Dim aircode As String = ""
        Dim refund_type As String = ""
        Dim refund_remarks As String = ""
        Dim FOP As String = ""
        Dim given_canc_penalty As String = ""
        Dim ticket_type As String = ""
        Dim DomInt As String = ""
        Dim tkt_basefare As String = ""
        Dim tkt_totalfare As String = ""

        For ri As Integer = 0 To dt.Rows.Count - 1

            given_canc_penalty = ""
            TicketNo = dt.Rows(ri)(1).ToString.Trim
            TripID = dt.Rows(ri)(0).ToString.Trim
            TicketOid = dt.Rows(ri)(4).ToString.Trim.ToUpper
            WaiverCode = dt.Rows(ri)(24).ToString.Trim
            refund_remarks = dt.Rows(ri)(26).ToString.Trim
            given_canc_penalty = dt.Rows(ri)(27).ToString.Trim
            ticket_type = dt.Rows(ri)(29).ToString.Trim.ToLower
            DomInt = dt.Rows(ri)(28).ToString.Trim
            ttkk = TicketNo
            FOP = ""
            tkt_basefare = ""
            tkt_totalfare = ""

            log("Ticket Number: " & TicketNo)
            log("given_canc_penalty: " & given_canc_penalty)
            log("Int Dom: " & DomInt)
            log("Ticket Type: " & ticket_type)

            If TicketNo.Length = 12 Then
                TicketNo = "0" & TicketNo
            End If

            If InStr(TicketNo, ".") AndAlso InStr(TicketNo, "+") Then
                UpdateFailed("Invalid ticket number", "")
                GoTo nxttkt
            End If
            aircode = TicketNo.Substring(0, 3)
            log("Airline Code: " & aircode)

            If aircode = "098" Or aircode = "228" Then
            Else
                log("It is not Air India/UK tkt. Going to next ticket")
                GoTo invalidpcc
            End If

            process_st = ""
            reason = ""
            GDSPNR = ""
            pnr_sts = ""
            tktResp = ""
            cancelitin = ""
            doi = ""
            refund_resp = ""
            tkt_status = ""
            up_itin_status = ""
            failure_remarks = ""
            refund_type = ""

            log("Details taken")

            If TicketNo = "" Or TicketOid = "" Then
                log("No ticket Number or tkt oid")
                If TicketNo = "" Then
                    reason = "Ticket Number Empty"
                ElseIf TicketOid = "" Then
                    reason = "Ticketing office ID not present"
                End If
                UpdateFailed(reason, "")
                GoTo nxttkt
            End If

            If InStr(active_pccs, TicketOid) Then
                log("This is valid pcc")
            Else
                GoTo invalidpcc
            End If

            If DomInt = "Domestic" Then
                DomInt = "D"
            End If

            If ticket_type = "expired" Then
                If DomInt = "D" Or DomInt = "I" Then
                Else
                    UpdateFailed("Invalid value in DOM/INT column", "")
                    GoTo nxttkt
                End If
            End If

            emures = EmulatePCC(TicketOid)
            If emures = "Failed" Then
                UpdateFailed("Unable to Emulate", "")
                GoTo nxttkt
            End If

            tktResp = GDSEntry("*TE/" & TicketNo)
            If InStr(tktResp, "UNABLE TO PROCESS ELECTRONIC TICKET DISPLAY") Then
                UpdateFailed("Unable to retrieve to ticket", "")
                GoTo nxttkt
            ElseIf InStr(tktResp, "EXCHANGED FOR:") Then
                UpdateFailed("Exchange Ticket", "")
                GoTo nxttkt
            End If

            GDSPNR = FindPNR(tktResp)
            If GDSPNR = "Failed" Then
                UpdateFailed("Unable to find PNR", "")
                GoTo nxttkt
            End If


            If given_canc_penalty = "" Then
                log("Canc penalty not given. Assigning 0.")
                given_canc_penalty = "0"
            End If

            tkt_status = Find_tkt_status(tktResp)
            If InStr(tkt_status, "OPEN") Then
            Else
                log("No open or arpt coupons present")
                UpdateFailed("No open coupons present", "")
                GoTo nxttkt
            End If

            Dim dummytkt As String = ""
            dummytkt = tkt_status.Replace("OPEN", "").Replace(",", "").Trim
            If dummytkt = "" Then
                log("Only open coupons present")
            Else
                log("Other status present")
                UpdateFailed("Other status present in the ticket", "")
                GoTo nxttkt
            End If

            doi = Find_DOI(tktResp)
            If doi = "" Then
                UpdateFailed("Unable to find DOI", "")
                GoTo nxttkt
            End If

            FOP = Find_FOP(tktResp)
            If FOP = "" Then
                UpdateFailed("Unable to find FOP", "")
                GoTo nxttkt
            End If

            If ticket_type = "expired" Then
                tkt_basefare = Find_Basefare(tktResp)
                If IsNumeric(tkt_basefare) = False Then
                    log("Invalid basefare")
                    UpdateFailed("Invalid basefare", "")
                    GoTo nxttkt
                End If
                tkt_totalfare = Find_Totalfare(tktResp)
                If IsNumeric(tkt_totalfare) = False Then
                    log("Invalid totalfare")
                    UpdateFailed("Invalid totalfare", "")
                    GoTo nxttkt
                End If
            End If

            Dim tv_resp As String = ""
            tv_resp = TravelDate_Validation(tktResp)
            If tv_resp = "Continue" Then
                log("Travel date valid")
            Else
                log("Travel date not valid")
                UpdateFailed("Travel Date validation failed", "")
                GoTo nxttkt
            End If

            pnr_sts = PNRret(GDSPNR)
            If pnr_sts = "Failed" Then
                'UpdateFailed("Unable to retrieve the PNR", "")
                'GoTo nxttkt
                'Dim purge_check As String = Purged_PNR_Check(doi, tktResp)
                'If purge_check = "Continue" Then
                '    log("No need to check the history. Continue to refund")
                '    GoTo rf_flow
                'Else
                '    UpdateFailed("Unable to retrieve the PNR", "")
                '    GoTo nxttkt
                'End If
                log("Purged PNR check is not needed. Going to full refund.")
                GoTo rf_flow
            End If

            Dim dvres As String = Check_Divided_PNR()
            If dvres = "DV_Present" Then
                log("Split PNR. Failing..")
                UpdateFailed("Divided PNR", "")
                GoTo nxttkt
            End If

            cancelitin = ItineraryCancellation()
            'If cancelitin = "ItinPresent" Then
            '    UpdateFailed("Itinerary present in the PNR", "")
            '    GoTo nxttkt
            'End If

            If cancelitin = "Success" Then
                Updateitincanx("Cancelled")
            ElseIf cancelitin = "NoItin" Then
                Updateitincanx("No Itinerary")
                'If given_canc_penalty = "0" Then
                '    Dim histres As String = ""
                '    histres = HistoryCheck(doi) 'here
                '    If histres = "FullRefund" Then
                '    ElseIf histres = "Failed1" Then
                '        UpdateFailed("Unable to read PNR history", "")
                '        GoTo nxttkt
                '    ElseIf histres = "Failed" Then
                '        UpdateFailed("No UN segment present in history", "")
                '        GoTo nxttkt
                '    End If
                'End If
            Else
                UpdateFailed("Unable to cancel the itinerary", "")
                GoTo nxttkt
            End If

rf_flow:
            If given_canc_penalty = "0" Then
                log("Full refund flow")
                refund_type = "Full Refund"
            Else
                log("Other refund flow")
                refund_type = "Other"
            End If
            refund_resp = FullRefundProcess(given_canc_penalty, TicketNo, doi, WaiverCode, refund_remarks, FOP, DomInt, ticket_type, tkt_basefare, tkt_totalfare)
            If refund_resp = "" Or refund_resp = "Failed" Then
                UpdateFailed("Unable to punch refund", refund_type)
            ElseIf refund_resp = "DOI_Issue" Then
                UpdateFailed("Unable to punch refund-TICKET ISSUE DATE OUT OF RANGE", refund_type)
            ElseIf refund_resp = "NoCreditCard" Then
                UpdateFailed("No credit card number found", refund_type)
            ElseIf refund_resp = "DOI_Invalid" Then
                UpdateFailed("Unable to punch refund-Invalid Date", refund_type)
            Else
                UpdateClosed(refund_resp, given_canc_penalty, "", refund_type)
            End If

nxttkt:
            Add_Refund_data(process_st, GDS, TicketOid, WaiverCode, "", "", failure_remarks, given_canc_penalty, refund_resp, "", refund_type, up_itin_status)
invalidpcc:
        Next

        MsgBox("Process Completed", MsgBoxStyle.OkOnly, "Refund Notice")
        End

    End Sub

    Dim excelconn1 As OleDbConnection

    Function PurgePNRRetrieval()

        Dim GDSResp = GDSEntry("I")
        GDSEntry("QXI")
        If GDSResp.Contains("SIGN IN") Then
            MsgBox("Please sign in into Galileo and try again.", MsgBoxStyle.OkOnly, "Refund Notice")
            End
        End If

        Dim excelstr1 As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\PurgedPNRs.xls;Extended Properties=""Excel 8.0;HDR=No;"""
        excelconn1 = New OleDbConnection(excelstr1)
        Dim strsql As String = "Select * from [Sheet1$] where F3 = 'Open'"
        Dim dt As New DataTable
        excelconn1.Open()
        Dim dbCommand As New OleDbCommand(strsql, excelconn1)
        Dim dataAdapter As New OleDbDataAdapter(dbCommand)
        dataAdapter.Fill(dt)
        excelconn1.Close()
        log("No of tickets: " & dt.Rows.Count)

        Dim GDS_PNR As String = ""
        Dim pnr_resp As String = ""
        Dim status As String = ""
        Dim remarks As String = ""
        For i As Integer = 0 To dt.Rows.Count - 1
            GDS_PNR = dt.Rows(i)(1).ToString.Trim
            pnr_resp = GDSEntry("PQ/R-" & GDS_PNR)
            status = ""
            remarks = ""
            If InStr(pnr_resp, "DATA MUST ONLY BE ACCESSED FOR BILLING DISPUTE REASONS") Then
                pnr_resp = GDSEntry("PQ/R-" & GDS_PNR & "/*CONFIRM")
                If InStr(pnr_resp, "QUEUE REQUESTED:") Then
                    Dim entry = con.ResponseLine(con.NumResponseLines - 2).ToString.Replace("<TABSTOP/>", "").Trim
                    If InStr(entry, "PQ/R-") Then
                        Dim ary As Array = Split(entry, " ")
                        entry = ary(ary.Length - 1).ToString.Replace("<CARRIAGE_RETURN/>", "").Replace("<SOM/>", "").Trim
                        pnr_resp = GDSEntry(entry)
                        If InStr(pnr_resp, "PDQ BOOKING FILE QUEUED FOR 24 HR RETRIEVAL") Then
                            status = "Closed"
                        ElseIf InStr(pnr_resp, "PDQ BF ON QUEUE") Then
                            remarks = "PDQ BF ON QUEUE"
                            status = "Failed"
                        End If
                    End If
                ElseIf InStr(pnr_resp, "PDQ - NO NAMES FOUND") Then
                    remarks = "PDQ - NO NAMES FOUND"
                    status = "Failed"
                End If
            ElseIf InStr(pnr_resp, "PDQ - RECORD LOCATOR INVALID") Then
                remarks = "PDQ - RECORD LOCATOR INVALID"
                status = "Failed"
            End If

            If status = "" Then
                status = "Failed"
                GoTo Ignore
            End If
            If excelconn1.State = ConnectionState.Closed Then
                excelconn1.Open()
            End If
            Dim strSQL2 = "Update [Sheet1$] set F3='" & status & "', F4 = '" & remarks & "', F5 = '" & Now.ToString & "' where F2='" & GDS_PNR & "'"
            log(strSQL2)
            Dim dbCommand2 As New OleDbCommand(strSQL2, excelconn1)
            Dim affcount = dbCommand2.ExecuteNonQuery()
            excelconn1.Close()
Ignore:
            GDSEntry("I")
        Next
        MsgBox("Process Completed")
        End
    End Function
    Function ReadTicketDetails()

        Dim excelstr1 As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\TicketDetails.xls;Extended Properties=""Excel 8.0;HDR=No;"""
        excelconn1 = New OleDbConnection(excelstr1)
        Dim strsql As String = "Select * from [Sheet1$] where F3 = 'Open'"
        Dim dt As New DataTable
        excelconn1.Open()
        Dim dbCommand As New OleDbCommand(strsql, excelconn1)
        Dim dataAdapter As New OleDbDataAdapter(dbCommand)
        dataAdapter.Fill(dt)
        excelconn1.Close()
        log("No of tickets: " & dt.Rows.Count)

        Dim TicketNo As String = ""
        Dim tktpcc As String = ""
        Dim emures As String = ""
        Dim tktResp As String = ""
        Dim update_tkt As String = ""

        For i As Integer = 0 To dt.Rows.Count - 1

            TicketNo = dt.Rows(i)(0).ToString.Trim
            update_tkt = TicketNo
            tktpcc = dt.Rows(i)(1).ToString.Trim
            tktResp = ""

            If TicketNo.Length = 12 Then
                TicketNo = "0" & TicketNo
            End If

            tktResp = GDSEntry("*TE/" & TicketNo)
            If InStr(tktResp, "UNABLE TO PROCESS ELECTRONIC TICKET DISPLAY") Then
                Dim Remarks As String = "Unable to retrieve ticket"

                If excelconn1.State = ConnectionState.Closed Then
                    excelconn1.Open()
                End If
                Dim strSQL2 = "Update [Sheet1$] set F3='Failed', F16='" & Remarks & "' where F1=" & update_tkt & " and F3='open'"
                log(strSQL2)
                Dim dbCommand2 As New OleDbCommand(strSQL2, excelconn1)
                Dim affcount = dbCommand2.ExecuteNonQuery()
                excelconn1.Close()
                Dim timestamp As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                refundservice.Update_Ticket_Details(TicketNo, tktpcc, "Failed", "", "", "", "", "", "", "", "", "", "", "", "", Remarks, ServiceToken, "Atlas", timestamp)
                GoTo nxttkt
            Else
                ReadTicket(tktResp, tktpcc, update_tkt, TicketNo)
            End If
nxttkt:
        Next
        MsgBox("Process Completed")
        End
    End Function

    Function ReadTicket(ByVal TktResp As String, ByVal agentpcc As String, ByVal updatetkt As String, ByVal TicketNo As String) As String

        Dim TktDt As New DataTable
        TktDt.Columns.Add("ID")
        TktDt.Columns.Add("Status")
        TktDt.Columns.Add("Airline")
        TktDt.Columns.Add("Flt")
        TktDt.Columns.Add("Class")
        TktDt.Columns.Add("Date")
        TktDt.Columns.Add("Origin")
        TktDt.Columns.Add("Destination")
        TktDt.Columns.Add("Time")
        TktDt.Columns.Add("FareBasis")
        TktDt.Columns.Add("CouponNo")
        TktDt.Columns.Add("O/X")
        TktDt.Columns.Add("Title")
        TktDt.Columns.Add("First_Name")
        TktDt.Columns.Add("Last_Name")

        Dim taxline As String = ""
        Dim PCC As String = ""
        Dim AirlinePNR As String = ""
        Try
            Dim TktRespAry = TktResp.Split(vbLf)
            Dim k As Integer = 0

            For kl As Integer = 5 To TktRespAry.Length - 2
                If TktRespAry(kl).ToString.Replace("]]><CARRIAGE_RETURN/></LINE>", "").Replace("<CARRIAGE_RETURN/></LINE>", "").Replace("<CARRIAGE_RETURN/>", "").Replace("<CARRIAGE_RETURN/></LINE>", "").Trim.Replace(")]]><SOM/></LINE>", "").Replace("<SOM/></LINE>", "") <> "" Then
                    If TktRespAry(kl).ToString.StartsWith("FARE") Then
                        taxline = TktRespAry(kl).ToString.Trim
                        Exit For
                    End If
                    If TktRespAry(kl).Length > 26 Then
                        If TktRespAry(kl).Substring(26, 3).Trim <> "" Then 'Farebasis
                            Dim TktStatus = TktRespAry(kl).Substring(3, 4).Trim
                            Dim TktAirline = TktRespAry(kl).Substring(8, 2).Trim
                            Dim TktFlt = TktRespAry(kl).Substring(11, 4).Trim
                            Dim TktClass = TktRespAry(kl).Substring(17, 1).Trim
                            Dim TktDate = TktRespAry(kl).Substring(20, 5).Trim
                            Dim XorO = TktRespAry(kl).Substring(25, 1).Trim
                            Dim TktOrg = TktRespAry(kl).Substring(26, 3).Trim
                            Dim TktDest = TktRespAry(kl).Substring(29, 3).Trim
                            Dim TktTime = TktRespAry(kl).Substring(34, 5).Trim
                            Dim TktFarebasis = TktRespAry(kl).Substring(42, 10).Trim.Split("/")(0)
                            Dim TktCoupon = TktRespAry(kl).Substring(61, 1)
                            TktDt.Rows.Add(k, TktStatus, TktAirline, TktFlt, TktClass, TktDate, TktOrg, TktDest, TktTime, TktFarebasis, TktCoupon, XorO, "", "", "")
                        End If
                    End If
                End If
            Next

            For kl As Integer = 0 To TktRespAry.Length - 1
                If TktRespAry(kl).ToString.StartsWith("PSEUDO:") Then
                    Dim ary As Array = Split(TktRespAry(kl).ToString, "PLATING ")
                    PCC = ary(0).ToString.Replace("PSEUDO:", "").Trim
                    Exit For
                End If
            Next

            For kl As Integer = TktRespAry.Length - 1 To 0 Step -1
                If TktRespAry(kl).ToString.StartsWith("RLOC ") Then
                    AirlinePNR = TktRespAry(kl).ToString.Trim
                    Dim ary As Array = Split(AirlinePNR, " ")
                    AirlinePNR = ary(ary.Length - 1)
                    Exit For
                End If
            Next
        Catch ex As Exception
            log("ReadTicket Exception:" & ex.ToString)
            Return "Failed"
        End Try

        Try
            If TktDt.Rows.Count > 0 Then
                Dim DOI As String = ""
                Dim travel_dates As String = ""
                Dim FOP As String = ""
                Dim couponstatus As String = ""
                Dim sectors As String = ""
                Dim bookingclass As String = ""
                Dim farebasis As String = ""
                Dim basefare As String = ""
                Dim GDS_PNR As String = ""
                Dim Airline_PNR As String = ""

                DOI = Find_DOI(TktResp)
                If DOI = "" Then
                    Return "Failed"
                End If
                FOP = Find_FOP(TktResp)
                If FOP = "" Then
                    Return "Failed"
                End If
                basefare = Find_Basefare_withcurrency(TktResp)
                If basefare = "" Then
                    Return "Failed"
                End If

                Dim total_taxamt As Integer = 0
                If InStr(taxline, " TAX ") Then
                    Dim ary As Array = Split(taxline, " TAX")
                    Dim taxamt As Integer = 0
                    For i As Integer = 1 To ary.Length - 1
                        If ary(i).ToString.Trim <> "TAX" AndAlso ary(i).ToString.Trim <> "" Then
                            taxamt = ary(i).ToString.Trim.Substring(0, ary(i).ToString.Trim.Length - 2)
                            total_taxamt = total_taxamt + taxamt
                        End If
                    Next
                Else
                    Return "Failed"
                End If

                GDS_PNR = FindPNR(TktResp)
                If GDS_PNR = "Failed" Then
                    GDS_PNR = ""
                End If

                For i As Integer = 0 To TktDt.Rows.Count - 1
                    travel_dates = travel_dates & "," & TktDt.Rows(i)("Date").ToString
                    couponstatus = couponstatus & "," & TktDt.Rows(i)("Status").ToString
                    sectors = sectors & "," & TktDt.Rows(i)("Origin").ToString & TktDt.Rows(i)("Destination").ToString
                    bookingclass = bookingclass & "," & TktDt.Rows(i)("Class").ToString
                    farebasis = farebasis & "," & TktDt.Rows(i)("FareBasis").ToString
                Next
                travel_dates = travel_dates.Trim(",")
                couponstatus = couponstatus.Trim(",")
                sectors = sectors.Trim(",")
                bookingclass = bookingclass.Trim(",")
                farebasis = farebasis.Trim(",")

                If excelconn1.State = ConnectionState.Closed Then
                    excelconn1.Open()
                End If
                Dim strSQL2 = "Update [Sheet1$] set F3='Closed',F4='" & DOI & "',F5='" & travel_dates & "',F6='" & FOP & "',F7='" & PCC & "',F8='" & couponstatus & "',F9='" & sectors & "',F10='" & bookingclass & "',F11='" & farebasis & "',F12='" & basefare & "',F13='" & total_taxamt & "',F14='" & GDS_PNR & "',F15='" & AirlinePNR & "',F16='' where F1=" & updatetkt & " and F3='Open'"
                log(strSQL2)
                Dim dbCommand2 As New OleDbCommand(strSQL2, excelconn1)
                Dim affcount = dbCommand2.ExecuteNonQuery()
                excelconn1.Close()
                Dim timestamp As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                refundservice.Update_Ticket_Details(TicketNo, agentpcc, "Closed", DOI, travel_dates, FOP, PCC, couponstatus, sectors, bookingclass, farebasis, basefare, total_taxamt, GDS_PNR, AirlinePNR, "", ServiceToken, "Atlas", timestamp)
                Return "Success"
            End If
        Catch ex As Exception
            log("ReadTicket Exception1:" & ex.ToString)
            Return "Failed"
        End Try
        Return ""

    End Function

    Function Check_Divided_PNR()
        log("Check divided PNR")
        Dim dv_res As String = GDSEntry("*DV")
        If InStr(dv_res, "** DIVIDED BOOKING DATA **") AndAlso InStr(dv_res, "DIVIDED BOOKINGS") Then
            log("Split PNR present")
            Return "DV_Present"
        ElseIf InStr(dv_res, "NO DIVIDED BOOKINGS EXIST") Then
            log("No divided bookings.")
            Return "NoSplitPNR"
        Else
            log("No split PNR present..")
            Return "NoSplitPNR"
        End If
    End Function

    Function Purged_PNR_Check(ByVal DOI As String, ByVal tktresp As String)

        log("Checking purged PNRs")
        Dim all_travel_dates As String = ""
        Dim start_range As String = "25MAR"
        Dim end_range As String = "24MAY"
        Dim range1 As String = "31MAR20"

        'If Convert.ToDateTime(DOI) <= Convert.ToDateTime(range1) Then
        log("Purged PNR. Issued before 31Mar20")
        'Return "Continue"
        all_travel_dates = Find_tkt_traveldates(tktresp)
        Dim ary As Array = Split(all_travel_dates, ",")
        Dim chk_date As String = ""
        Dim tkt_validity As String = ""
        For i As Integer = 0 To ary.Length - 1
            chk_date = ary(i).ToString
            log("Dep date to check: " & chk_date)
            If (Convert.ToDateTime(chk_date) >= Convert.ToDateTime(start_range)) AndAlso (Convert.ToDateTime(chk_date) <= Convert.ToDateTime(end_range)) Then
                tkt_validity = tkt_validity & "," & "Valid"
            Else
                tkt_validity = tkt_validity & "," & "Invalid"
                Exit For
            End If
        Next
        If InStr(tkt_validity, "Invalid") Then
            log("Invalid present")
        Else
            Return "Continue"
        End If
        'End If
        Return "Failed"

    End Function

    Function TravelDate_Validation(ByVal tktresp As String)

        log("Checking travel date validation")
        Dim start_range As String = "25MAR"
        Dim end_range As String = "24MAY"
        Dim all_travel_dates As String = ""

        all_travel_dates = Find_tkt_traveldates(tktresp)
        Dim ary As Array = Split(all_travel_dates, ",")
        Dim chk_date As String = ""
        Dim tkt_validity As String = ""
        For i As Integer = 0 To ary.Length - 1
            chk_date = ary(i).ToString
            log("Dep date to check: " & chk_date)
            If (Convert.ToDateTime(chk_date) >= Convert.ToDateTime(start_range)) AndAlso (Convert.ToDateTime(chk_date) <= Convert.ToDateTime(end_range)) Then
                tkt_validity = tkt_validity & "," & "Valid"
            Else
                tkt_validity = tkt_validity & "," & "Invalid"
                Exit For
            End If
        Next
        If InStr(tkt_validity, "Invalid") Then
            log("Invalid present")
        Else
            Return "Continue"
        End If
        Return "Failed"

    End Function

    Sub Add_Refund_data(ByVal process_status As String, ByVal GDS As String, ByVal Ticketing_PCC As String, ByVal Waiver_Code As String, ByVal Is_Cancellation_Needed As String, ByVal Agent_Cancellation_Penalty As String, ByVal Remarks As String, ByVal Cancellation_Charges As String, ByVal Refund_Amount As String, ByVal Reference_Number As String, ByVal Refund_Type As String, ByVal Itinerary_Status As String)
        log("Data insertion")
        Dim timestamp As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        Dim datares As String = refundservice.Set_Agent_Refund_Details(ttkk, process_status, GDS, Ticketing_PCC, Waiver_Code, Is_Cancellation_Needed, Agent_Cancellation_Penalty, Remarks, Cancellation_Charges, Refund_Amount, Reference_Number, timestamp, Refund_Type, Itinerary_Status, timestamp, agentname, ServiceToken)
        log("Data Res: " & datares)
    End Sub

    Function Find_tkt_status(ByVal tktresp As String)

        log("Finding tkt status")
        Dim tktStatus As String = ""
        Dim TktRespAry As Array = Split(tktresp, vbLf)

        For kl As Integer = 5 To TktRespAry.Length - 2
            If TktRespAry(kl).ToString.Replace("]]><CARRIAGE_RETURN/></LINE>", "").Replace("<CARRIAGE_RETURN/></LINE>", "").Replace("<CARRIAGE_RETURN/>", "").Replace("<CARRIAGE_RETURN/></LINE>", "").Trim.Replace(")]]><SOM/></LINE>", "").Replace("<SOM/></LINE>", "") <> "" Then
                If TktRespAry(kl).ToString.StartsWith("FARE") Then
                    Exit For
                End If
                If TktRespAry(kl).Length > 26 Then 'on 12Dec Reason:  To adapt the line ----099----]]><CARRIAGE_RETURN/></LINE>
                    If TktRespAry(kl).Substring(26, 3).Trim <> "" Then 'Farebasis
                        tktStatus = tktStatus & "," & TktRespAry(kl).Substring(3, 4).Trim
                    End If
                End If
            End If
        Next
        log("Ticket Status: " & tktStatus)
        Return tktStatus

    End Function

    Function Find_tkt_traveldates(ByVal tktresp As String)

        log("Finding tkt depdates")
        Dim dep_dates As String = ""
        Dim TktRespAry As Array = Split(tktresp, vbLf)

        For kl As Integer = 5 To TktRespAry.Length - 2
            If TktRespAry(kl).ToString.Replace("]]><CARRIAGE_RETURN/></LINE>", "").Replace("<CARRIAGE_RETURN/></LINE>", "").Replace("<CARRIAGE_RETURN/>", "").Replace("<CARRIAGE_RETURN/></LINE>", "").Trim.Replace(")]]><SOM/></LINE>", "").Replace("<SOM/></LINE>", "") <> "" Then
                If TktRespAry(kl).ToString.StartsWith("FARE") Then
                    Exit For
                End If
                If TktRespAry(kl).Length > 26 Then 'on 12Dec Reason:  To adapt the line ----099----]]><CARRIAGE_RETURN/></LINE>
                    If TktRespAry(kl).Substring(26, 3).Trim <> "" Then 'Farebasis
                        dep_dates = dep_dates & "," & TktRespAry(kl).Substring(20, 5).Trim
                    End If
                End If
            End If
        Next
        dep_dates = dep_dates.Trim(",")
        log("Ticket dep dates: " & dep_dates)
        Return dep_dates

    End Function

    Function HistoryCheck(ByVal DOI As String)

        log("History Check")

        Dim resp = GDSEntry("*HIA")
        Dim RespXml = convertHistoryXML(resp)
        Dim HistXML As New XmlDocument
        HistXML.LoadXml(RespXml)
        Dim XmlNodeList = HistXML.SelectNodes("//action")
        Dim cancpresent As Boolean = False

        Try
            For Each xmlnode In XmlNodeList
                Dim RF = xmlnode.Attributes.GetNamedItem("id").Value
                Dim ActionItemLst = xmlnode.SelectNodes("ACTIONITEM")
                For Each xmlnode1 In ActionItemLst
                    If xmlnode1.ChildNodes.count > 2 Then
                        'If xmlnode1.SelectSingleNode("ACTIONCOMMIT").InnerText.ToString.Trim = "XS" Then
                        '    cancpresent = True
                        '    Dim RFDateTime = RF.ToString.Trim.Substring(RF.ToString.Trim.Length - 12)
                        '    Dim RFdateTimeAry = RFDateTime.Split("/")
                        '    Dim TravelYr As String = GetTravelYear(DOI, xmlnode1.SelectSingleNode("DOJ").InnerText)
                        '    Dim TravelDate = xmlnode1.SelectSingleNode("DOJ").InnerText & TravelYr & " " & xmlnode1.SelectSingleNode("DEP").InnerText.ToString.Substring(0, 2) & ":" & xmlnode1.SelectSingleNode("DEP").InnerText.ToString.Substring(2)
                        '    Dim actioncommit As String = xmlnode1.SelectSingleNode("ACTIONCOMMIT").InnerText.ToString.Trim
                        '    Dim newCRDTime As String = RFdateTimeAry(1).Trim & TravelYr & " " & RFdateTimeAry(0).Trim.Substring(0, 2) & ":" & RFdateTimeAry(0).Trim.Substring(2, 2)
                        '    newCRDTime = CDate(newCRDTime).AddHours(5).AddMinutes(30)
                        '    log("New CR time: " & newCRDTime)
                        '    log("Action Commit1: " & actioncommit)

                        '    Dim todate As Date = TravelDate
                        '    Dim dat As Date = newCRDTime
                        '    Dim diffhours As Integer = 0
                        '    diffhours = todate.Subtract(dat).TotalHours
                        '    log("Diff hours: " & diffhours)

                        '    If diffhours <= 48 Then
                        '        log("Booking cancelled within 72 hours")
                        '        Return "Canc72"
                        '    End If
                        'End If
                        Dim n = xmlnode1.SelectNodes("STATUS")
                        If n.Count > 0 AndAlso xmlnode1.SelectSingleNode("STATUS").InnerText.ToString.Trim.Contains("UN") Then
                            log("UN seg present. Full refund.")
                            Return "FullRefund"
                        End If
                    End If
                Next
            Next
        Catch ex As Exception
            log("Hist reader issue: " & ex.Message.ToString)
            Return "Failed1"
        End Try

        'If cancpresent = False Then
        '    Return "NoCanc"
        'Else
        '    Return ""
        'End If

        Return "Failed"
    End Function

    Function GetTravelYear(doi As String, traveldate As String)
        Dim TravelYr As String = ""
        If CDate(doi).ToString("ddMMM") <= CDate(traveldate) Then
            TravelYr = doi.ToString.Substring(5)
        ElseIf CDate(doi).ToString("ddMMM") > CDate(traveldate) Then
            TravelYr = doi.ToString.Substring(5) + 1
        End If
        Return TravelYr
    End Function

    Function FindPNR(ByVal tktresp As String)
        Dim rary As Array = Split(tktresp, "RLOC 1G")
        Dim pnr As String = ""
        Try
            pnr = rary(1).ToString.Trim.Substring(0, 6)
            log("PNR Found: " & pnr)
            If pnr.Length = 6 Then
                Return pnr
            Else
                Return "Failed"
            End If
        Catch ex As Exception
            log("Unable to find the GDS PNR")
            Return "Failed"
        End Try
    End Function

    Function Find_DOI(ByVal tktresp As String)
        Dim rary As Array = Split(tktresp, vbLf)
        Dim doi As String = ""
        For h As Integer = 0 To rary.Length - 1
            If InStr(rary(h).ToString, "ISSUED:") Then
                doi = rary(h).ToString.Trim
                Exit For
            End If
        Next
        If doi <> "" Then
            rary = Nothing
            rary = Split(doi, "ISSUED:")
            doi = rary(1).ToString.Trim.Substring(0, 7)
            Return doi
        End If
        Return ""
    End Function

    Function Find_FOP(ByVal tktresp As String)
        log("Finding FOP")
        Dim rary As Array = Split(tktresp, vbLf)
        Dim fop As String = ""
        For h As Integer = 0 To rary.Length - 1
            If InStr(rary(h).ToString, "FOP:") Then
                fop = rary(h).ToString.Trim
                Exit For
            End If
        Next
        If fop <> "" Then
            rary = Nothing
            rary = Split(fop, "FOP:")
            fop = rary(1).ToString.Trim
            Return fop
        End If
        Return ""
    End Function

    Function Find_Basefare(ByVal tktresp As String)
        Dim rary As Array = Split(tktresp, vbLf)
        Dim basefare As String = ""
        For h As Integer = 3 To rary.Length - 1
            If rary(h).ToString.Trim.StartsWith("FARE ") Then
                Dim fareary As Array = Split(rary(h).ToString, "TAX")
                basefare = fareary(0).ToString.Replace("FARE", "").Trim
                basefare = basefare.Substring(3).Trim
                Exit For
            End If
        Next
        log("Basefare: " & basefare)
        Return basefare
    End Function

    Function Find_Basefare_withcurrency(ByVal tktresp As String)
        Dim rary As Array = Split(tktresp, vbLf)
        Dim basefare As String = ""
        For h As Integer = 3 To rary.Length - 1
            If rary(h).ToString.Trim.StartsWith("FARE ") Then
                Dim fareary As Array = Split(rary(h).ToString, "TAX")
                basefare = fareary(0).ToString.Replace("FARE", "").Trim
                basefare = basefare.Replace(" ", "").Trim.Insert(3, " ")
                Exit For
            End If
        Next
        log("Basefare: " & basefare)
        Return basefare
    End Function

    Function Find_Totalfare(ByVal tktresp As String)
        Dim rary As Array = Split(tktresp, vbLf)
        Dim totalfare As String = ""
        For h As Integer = 3 To rary.Length - 1
            If rary(h).ToString.Trim.StartsWith("TOTAL ") Then
                totalfare = rary(h).ToString.Replace("TOTAL", "").Trim
                totalfare = totalfare.Substring(3).Trim
                Exit For
            End If
        Next
        log("Basefare: " & totalfare)
        Return totalfare
    End Function
    Function PNRret(ByVal pnr As String) As String

        log("PNRRET")
        Dim sts As String = ""
        Try
            log("PNR:" & pnr)
            Dim Resp = GDSEntry("*" & pnr)
            Dim RespAry As Array = Resp.Split(vbLf)
            If Resp.Contains("UNABLE TO RETRIEVE") Then
                sts = "Failed"
            ElseIf RespAry.Length < 4 Then
                sts = "Failed"
            Else
                sts = "Success"
            End If
        Catch ex As Exception
            log("PNRret exception:" & ex.ToString())
            sts = "Failed"
        End Try
        Return sts
    End Function

    Function EmulatePCC(ByVal OID As String) As String
        log("Emulation")
checkagain:
        Dim EmulateResp = GDSEntry("SEM/" & OID & "/AG")
        If EmulateResp.Contains("PROCEED") Then
            Return "Success"
        ElseIf EmulateResp.Contains("FINISH OR IGNORE") Then
            GDSEntry("I")
            GoTo checkagain
        Else
            Return "Failed"
        End If
    End Function

    Function ItineraryCancellation() As String

        log("Itin cancellation")
        Dim Resp As String = GDSEntry("*IA")
        If Resp.Contains("NO ITINERARY") Then
            log("NO ITINERARY")
            Return "NoItin"
        Else
            log("Itin present")
            Return "ItinPresent"
        End If

        Resp = GDSEntry("XI")
        If Resp.Contains("ITINERARY CANCELLED") Then
            Resp = GDSEntry("R.AUTOREFUND")
            Resp = GDSEntry("ER")
            If Resp.Contains("WARNING") Or Resp.Contains("FILED FARES CANCELLED") Then
                Resp = GDSEntry("ER")
            End If
        End If

        GDSEntry("*R")
        Resp = GDSEntry("*IA")
        If Resp.Contains("NO ITINERARY") Then
            log("Itin cancellation success")
            Return "Success"
        Else
            log("Itin still present")
            Return "Failed"
        End If

    End Function

    Function UpdateFailed(ByVal RemarkText As String, ByVal TypeofRefund As String) As String

        log("Update Fun-Failed")
        process_st = "Failed"
        failure_remarks = RemarkText
        Dim affcount As Integer = 0
        Dim strSQL2 As String = ""
        Dim dbCommand2 As New OleDbCommand

        Try
            If excelconn.State = ConnectionState.Closed Then
                excelconn.Open()
            End If
            strSQL2 = "Update [Sheet1$] set F3 = 'Failed', F18 = '" & RemarkText & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2=" & ttkk & " and F3='open'"
            'strSQL2 = "Update [Sheet1$] set F3 = 'Failed', F18 = '" & RemarkText & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2='" & ttkk & "' and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, excelconn)
            affcount = dbCommand2.ExecuteNonQuery()
            excelconn.Close()
            Try
                If affcount = 0 Then
                    If excelconn.State = ConnectionState.Closed Then
                        excelconn.Open()
                    End If
                    strSQL2 = "Update [Sheet1$] set F3 = 'Failed', F18 = '" & RemarkText & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2='" & ttkk & "' and F3='open'"
                    log(strSQL2)
                    dbCommand2 = New OleDbCommand(strSQL2, excelconn)
                    dbCommand2.ExecuteNonQuery()
                    excelconn.Close()
                End If
            Catch ex As Exception

            End Try
            Return "Failed"
        Catch ex As Exception
            If excelconn.State = ConnectionState.Closed Then
                excelconn.Open()
            End If
            strSQL2 = "Update [Sheet1$] set F3 = 'Failed', F18 = '" & RemarkText & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2=" & ttkk & " and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, excelconn)
            dbCommand2.ExecuteNonQuery()
            excelconn.Close()
            Return "Failed"
        End Try

    End Function

    Function UpdateClosed(ByVal RefundAmount As String, ByVal CancelfeeAmt As String, ByVal ReferenceNum As String, ByVal TypeofRefund As String) As String

        log("Update Fun-Closed")
        process_st = "Closed"
        failure_remarks = ""
        Dim affcount As Integer = 0
        Dim strSQL2 As String = ""
        Dim dbCommand2 As New OleDbCommand

        Try
            If excelconn.State = ConnectionState.Closed Then
                excelconn.Open()
            End If
            'strSQL2 = "Update [Sheet1$] set F3 = 'Closed', F18 = '', F19 = '" & CancelfeeAmt & "', F20 = '" & RefundAmount & "', F21 = '" & ReferenceNum & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2='" & ttkk & "' and F3='open'"
            strSQL2 = "Update [Sheet1$] set F3 = 'Closed', F18 = '', F19 = '" & CancelfeeAmt & "', F20 = '" & RefundAmount & "', F21 = '" & ReferenceNum & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2=" & ttkk & " and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, excelconn)
            affcount = dbCommand2.ExecuteNonQuery()
            excelconn.Close()
            Try
                If affcount = 0 Then
                    If excelconn.State = ConnectionState.Closed Then
                        excelconn.Open()
                    End If
                    strSQL2 = "Update [Sheet1$] set F3 = 'Closed', F18 = '', F19 = '" & CancelfeeAmt & "', F20 = '" & RefundAmount & "', F21 = '" & ReferenceNum & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2='" & ttkk & "' and F3='open'"
                    log(strSQL2)
                    dbCommand2 = New OleDbCommand(strSQL2, excelconn)
                    dbCommand2.ExecuteNonQuery()
                    excelconn.Close()
                End If
            Catch ex As Exception

            End Try
            Return "Success"
        Catch ex As Exception
            If excelconn.State = ConnectionState.Closed Then
                excelconn.Open()
            End If
            strSQL2 = "Update [Sheet1$] set F3 = 'Closed', F18 = '', F19 = '" & CancelfeeAmt & "', F20 = '" & RefundAmount & "', F21 = '" & ReferenceNum & "', F23 = '" & Now.ToString & "', F24 = '" & TypeofRefund & "' where F2=" & ttkk & " and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, excelconn)
            dbCommand2.ExecuteNonQuery()
            excelconn.Close()
            Return "Success"
        End Try

    End Function

    Function Updateitincanx(ByVal itin_status As String) As String

        log("Update Fun-Failed")
        up_itin_status = itin_status
        Dim affcount As Integer = 0
        Dim strSQL2 As String = ""
        Dim dbCommand2 As New OleDbCommand

        Try
            If excelconn.State = ConnectionState.Closed Then
                excelconn.Open()
            End If
            strSQL2 = "Update [Sheet1$] set F26 = '" & itin_status & "' where F2='" & ttkk & "' and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, excelconn)
            affcount = dbCommand2.ExecuteNonQuery()
            excelconn.Close()
            Try
                If affcount = 0 Then
                    If excelconn.State = ConnectionState.Closed Then
                        excelconn.Open()
                    End If
                    strSQL2 = "Update [Sheet1$] set F26 = '" & itin_status & "' where F2='" & ttkk & "' and F3='open'"
                    log(strSQL2)
                    dbCommand2 = New OleDbCommand(strSQL2, excelconn)
                    dbCommand2.ExecuteNonQuery()
                    excelconn.Close()
                End If
            Catch ex As Exception

            End Try
            Return "Failed"
        Catch ex As Exception
            If excelconn.State = ConnectionState.Closed Then
                excelconn.Open()
            End If
            strSQL2 = "Update [Sheet1$] set F26 = '" & itin_status & "' where F2=" & ttkk & " and F3='open'"
            log(strSQL2)
            dbCommand2 = New OleDbCommand(strSQL2, excelconn)
            dbCommand2.ExecuteNonQuery()
            excelconn.Close()
            Return "Failed"
        End Try

    End Function

    Function GDSEntry(ByVal entry As String) As String
        log("GDS entry fun")
        con.Close()
        con.Open()
        log("<FORMAT>" & entry & "</FORMAT>")
        con.MakeEntry("<FORMAT>" & entry & "</FORMAT>")
        Do While con.more = 1
            con.GetMore(1, 0)
        Loop
        Dim outpt As String = ""
        For q As Integer = 0 To con.NumResponseLines - 1
            outpt = outpt & vbLf & con.ResponseLine(q).ToString
        Next
        outpt = outpt.Replace("<CARRIAGE_RETURN/>", "").Replace("<SOM/>", "").Trim
        log(con.ResponseXML)
        Return outpt
    End Function

    Function FullRefundProcess(ByVal cancpenalty As String, ByVal tkt_no As String, ByVal DOI As String, ByVal WaiverCode As String, ByVal refund_remarks As String, ByVal FOP As String, ByVal DomInt As String, ByVal ticket_type As String, ByVal tkt_basefare As String, ByVal tkt_totalfare As String)

        Dim customerRefAmt As String = ""
        Dim non_refundable_taxes As String = ""
        Dim range1 As String = "31MAR20"
        Dim cc_fop_bool As Boolean = False

        If Convert.ToDateTime(DOI) <= Convert.ToDateTime(range1) Then
            log("Ticket issued on/before 31Mar20. K3 is non-refundable")
            non_refundable_taxes = "K3"
        End If
        log("Final non refund tax list: " & non_refundable_taxes)

        Try

            Dim Checked As Boolean = False
            tkt_no = tkt_no.Replace(" ", "")
Process:
            Dim refundQry As String = ""
            GDSEntry("I")
            If ticket_type = "expired" Then
                refundQry = "TRNE" & tkt_no & "/" & CDate(DOI).ToString("ddMMM")
            Else
                refundQry = "TRNE" & tkt_no & "/" & CDate(DOI).ToString("ddMMMyy")
            End If
            log(refundQry)
            con.MakeEntry("<FORMAT>" & refundQry & "</FORMAT>")
            log(con.ResponseXML)

            If con.ResponseLine(0).ToString.Contains("TICKET ISSUE DATE OUT OF RANGE") Then
                log("Issue date out of range")
                Return "DOI_Issue"
            ElseIf con.ResponseLine(0).ToString.Contains("INVALID DATE") Then
                log("Issue date invalid")
                Return "DOI_Invalid"
            End If

            If ticket_type = "expired" Then
                log("Expired ticket flow")
                If con.ResponseXML.Contains("NO SYSTEM DATA AVAILABLE") AndAlso con.ResponseXML.Contains("DOM/INT") Then
                    Dim ddf As New ArrayList
                    Dim strd As String = ""
                    For i As Integer = 0 To con.NumResponseLines - 1
                        strd = con.ResponseLine(i).Replace("<CARRIAGE_RETURN/>", "").Replace("<TABSTOP/>", ChrW(183)).Replace("<SOM/>", " ")
                        If strd.Contains("DOM/INT ·.") Then
                            strd = strd.Replace("DOM/INT ·.", "DOM/INT ·" & DomInt)
                        End If
                        If FOP = "CASH" Then
                            If strd.Contains("CASH AMT EX TAX PAID") Then
                                Dim acr As String = tkt_basefare
                                acr = acr.PadRight(9, ".")
                                strd = strd.Replace("CASH AMT EX TAX PAID   ·.........", "CASH AMT EX TAX PAID   ·" & acr)
                            End If
                            If strd.Contains("CASH AMT USED      ·.........") Then
                                Dim acr As String = "0"
                                acr = acr.PadRight(9, ".")
                                strd = strd.Replace("CASH AMT USED      ·.........", "CASH AMT USED      ·" & acr)
                            End If
                        ElseIf FOP.Length > 5 AndAlso InStr(FOP, "XXXX") Then
                            If strd.Contains("CREDIT AMT EX TAX PAID") Then
                                Dim acr As String = tkt_basefare
                                acr = acr.PadRight(9, ".")
                                strd = strd.Replace("CREDIT AMT EX TAX PAID ·.........", "CREDIT AMT EX TAX PAID ·" & acr)
                            End If
                            If strd.Contains("CREDIT AMT USED    ·") Then
                                Dim acr As String = "0"
                                acr = acr.PadRight(9, ".")
                                strd = strd.Replace("CREDIT AMT USED    ·.........", "CREDIT AMT USED    ·" & acr)
                            End If
                        End If

                        If strd.Contains("CANCELLATION CHARGE ·........") Then
                            Dim acr As String = cancpenalty
                            acr = acr.PadRight(8, ".")
                            strd = strd.Replace("CANCELLATION CHARGE ·........", "CANCELLATION CHARGE ·" & acr)
                        End If

                        If strd.Contains("UNUSED TAXES TO BE REFUNDED Y/N ·.") Then
                            strd = strd.Replace("UNUSED TAXES TO BE REFUNDED Y/N ·.", "UNUSED TAXES TO BE REFUNDED Y/N ·Y")
                        End If
                        ddf.Add(strd.PadRight(&H40, " "c))
                    Next
                    Dim str = Strings.Join(ddf.ToArray, "")
                    con.MakeEntry("<FORMAT>" & str & "</FORMAT>") 'will Tax brkup
                    log("Rf entry1: " & str)
                    log(con.ResponseXML)
                Else
                    log("invalid response format")
                    Return "Failed"
                End If
            Else
                If con.ResponseXML.Contains("COMM RATE") Then
                    log("Comm rate present.")

                    Dim ddf As New ArrayList
                    Dim strd As String = ""

                    For i As Integer = 0 To con.NumResponseLines - 1
                        strd = con.ResponseLine(i).Replace("<CARRIAGE_RETURN/>", "").Replace("<TABSTOP/>", ChrW(183)).Replace("<SOM/>", " ")
                        If strd.Contains("UNUSED TAXES TO BE REFUNDED Y/N ·.") Then
                            strd = strd.Replace("UNUSED TAXES TO BE REFUNDED Y/N ·.", "UNUSED TAXES TO BE REFUNDED Y/N ·Y")
                        End If

                        If strd.Contains("CANCELLATION CHARGE ·........") Then
                            Dim acr As String = cancpenalty
                            acr = acr.PadRight(8, ".")
                            strd = strd.Replace("CANCELLATION CHARGE ·........", "CANCELLATION CHARGE ·" & acr)
                        End If

                        If FOP = "CASH" Then
                            If strd.Contains("CASH AMT USED      ·.........") Then
                                Dim acr As String = "0"
                                acr = acr.PadRight(9, ".")
                                strd = strd.Replace("CASH AMT USED      ·.........", "CASH AMT USED      ·" & acr)
                            End If
                        ElseIf FOP.Length > 5 AndAlso InStr(FOP, "XXXX") Then
                            If strd.Contains("CREDIT AMT USED    ·.........") Then
                                cc_fop_bool = True
                                Dim acr As String = "0"
                                acr = acr.PadRight(9, ".")
                                strd = strd.Replace("CREDIT AMT USED    ·.........", "CREDIT AMT USED    ·" & acr)
                            End If
                        End If
                        ddf.Add(strd.PadRight(&H40, " "c))
                    Next

                    Dim str = Strings.Join(ddf.ToArray, "")
                    con.MakeEntry("<FORMAT>" & str & "</FORMAT>") 'will Tax brkup
                    log("Rf entry: " & str)
                    log(con.ResponseXML)
                Else
                    log("COMM RATE not present")
                    Return "Failed"
                End If
            End If


            Dim nr_tax_values As String = ""
            If con.ResponseXML.Contains("TRNTAX") Then
                log("TRN tax present1")
                If non_refundable_taxes <> "" Then
                    log("Non refundable taxes present: " & non_refundable_taxes)
                    Dim nary As Array = Split(non_refundable_taxes, ",")
                    Dim non_tax_code As String = ""
                    For k As Integer = 0 To nary.Length - 1
                        non_tax_code = nary(k).ToString
                        For i As Integer = 0 To con.NumResponseLines - 1
                            log("Tax line: " & con.ResponseLine(i).ToString)
                            Dim dummy = con.ResponseLine(i).ToString
                            If dummy.Trim.StartsWith("BT01") Then
                                Exit For
                            End If
                            If InStr(con.ResponseLine(i).ToString, non_tax_code) Then
                                log("Non-refundable tax present: " & non_tax_code & " ")
                                Dim taxline As String = con.ResponseLine(i).ToString.Replace("<CARRIAGE_RETURN/>", "").Replace("<TABSTOP/>", ChrW(183)).Replace("<SOM/>", "")
                                Dim taxary As Array = Split(taxline, " ")
                                For j As Integer = 0 To taxary.Length - 1
                                    If taxary(j).ToString.Trim.EndsWith(non_tax_code) Then
                                        log("NR tax found: " & taxary(j).ToString)
                                        Dim NR_tax_value As String = taxary(j).ToString.Trim
                                        NR_tax_value = NR_tax_value.Replace(".", "").Replace("·", "").Replace(non_tax_code, "").Trim
                                        log("NR Tax value: " & NR_tax_value)
                                        If NR_tax_value <> "" Then
                                            nr_tax_values = nr_tax_values & "," & non_tax_code & "-" & NR_tax_value
                                        End If
                                        GoTo nexttax
                                    End If
                                Next
                            End If
                        Next
nexttax:
                    Next
                    nr_tax_values = nr_tax_values.Trim(",")
                    log("All NR tax values: " & nr_tax_values)
                End If
            End If

            If con.ResponseXML.Contains("TRNTAX") Then
                log("TRNTAX present")
                Dim ddf As New ArrayList
                Dim strd As String = ""
                Dim go_bool As Boolean = False

                For i As Integer = 0 To con.NumResponseLines - 1
                    strd = con.ResponseLine(i).Replace("<CARRIAGE_RETURN/>", "").Replace("<TABSTOP/>", ChrW(183)).Replace("<SOM/>", " ")
                    If strd.Trim.StartsWith("BT01") Then
                        go_bool = True
                    End If
                    If nr_tax_values <> "" AndAlso i > 0 AndAlso go_bool = False Then
                        log("Non refund taxes taken from")
                        Dim nary As Array = Split(nr_tax_values, ",")
                        Dim nr_tax_code As String = ""
                        Dim nr_tax_val As String = ""
                        For k As Integer = 0 To nary.Length - 1
                            nr_tax_code = nary(k).ToString
                            log("Tax set to clear: " & nr_tax_code)
                            Dim vary As Array = Split(nr_tax_code, "-")
                            nr_tax_code = vary(0).ToString
                            nr_tax_val = vary(1).ToString
                            log("Tax code to replace: " & nr_tax_code)
                            log("Tax val to replace: " & nr_tax_val)
                            If InStr(strd, "·" & nr_tax_code & " ") Then
                                log("NR tax found1")
                                Dim str3 As String = ""
                                str3 = "·" & nr_tax_val.PadRight(8, ".") & "·" & nr_tax_code
                                log("Replace str3: " & str3)
                                strd = strd.Replace(str3, "·........·..")
                            End If
                        Next
                    End If
                    ddf.Add(strd.PadRight(&H40, " "c))
                Next

                Dim str = Strings.Join(ddf.ToArray, "")
                con.MakeEntry("<FORMAT>" & str & "</FORMAT>")
                log("Rf entry1: " & str)
                log(con.ResponseXML)
            End If

            If con.ResponseXML.Contains("TRN2") And con.ResponseXML.Contains("REFUND AMOUNT") And con.ResponseXML.Contains("THIRD SCREEN Y/N") Then
                log("TRN2 present")
                Dim ddf2 As New ArrayList
                Dim strd As String = ""

                Dim card_no As String = ""
                Dim cardno_db As String = ""
                Dim card_code As String = ""
                Dim expiry_date As String = ""
                Dim refund_amt As String = ""

                If FOP.Length > 5 AndAlso InStr(FOP, "XXXX") Then
                    Dim fopary As Array = Split(FOP, "-")
                    card_no = fopary(0).ToString
                    Dim last_4_digit As String = card_no.Substring(card_no.Length - 4)
                    card_code = card_no.Substring(0, 2)

                    For c As Integer = 0 To cdt.Rows.Count - 1
                        cardno_db = cdt.Rows(c)("CARD_NUMBER").ToString.Trim
                        If cardno_db.EndsWith(last_4_digit) Then
                            cardno_db = cardno_db.Replace(card_code, "").Trim
                            expiry_date = cdt.Rows(c)("EXPIRY_DATE").ToString
                            Exit For
                        Else
                            cardno_db = ""
                        End If
                    Next
                    If cardno_db = "" Then
                        log("No credit card number found")
                        Return "NoCreditCard"
                    End If
                    log("Credit card code: " & cardno_db)
                    log("Expiry date: " & expiry_date)

                    If ticket_type = "expired" Then
                        log("Expired ticket. Need to calculate refund amount")
                        Dim taxamount As String = ""
                        Dim taxamt As Integer = 0
                        If nr_tax_values <> "" Then
                            log("NR tax found")
                            Dim tary As Array = Split(nr_tax_values, ",")
                            For h As Integer = 0 To tary.Length - 1
                                taxamt = taxamt + Convert.ToInt32(tary(h).ToString.Substring(3))
                            Next
                        End If
                        log("Total deducted tax: " & taxamt)
                        log("Total fare: " & tkt_totalfare)
                        refund_amt = Convert.ToInt32(tkt_totalfare) - taxamt
                        log("Refund amount to be updated: " & refund_amt)
                    End If
                End If


                For i = 0 To con.NumResponseLines - 1
                    strd = con.ResponseLine(i).Replace("<CARRIAGE_RETURN/>", "").Replace("<TABSTOP/>", ChrW(183)).Replace("<SOM/>", " ")
                    If strd.Contains("THIRD SCREEN Y/N ·.") Then
                        strd = strd.Replace("THIRD SCREEN Y/N ·.", "THIRD SCREEN Y/N ·Y")
                    ElseIf strd.Contains("*TRN2   A/L AUTHORITY ·.") Then
                        If WaiverCode <> "" Then
                            Dim acr As String = ""
                            For li = WaiverCode.Length To 13
                                acr = acr & "."
                            Next
                            acr = "*TRN2   A/L AUTHORITY ·" & WaiverCode & acr
                            strd = strd.Replace("*TRN2   A/L AUTHORITY ·..............", acr)
                        End If
                    End If

                    '''''credit card details'''''
                    If FOP.Length > 5 AndAlso InStr(FOP, "XXXX") Then
                        If strd.Contains("CREDIT CARD CODE ·") Then
                            strd = strd.Replace("CREDIT CARD CODE ·..", "CREDIT CARD CODE ·" & card_code)
                        End If
                        If strd.Contains("CARD NUMBER ·") Then
                            cardno_db = cardno_db.Replace(card_code, "").Trim
                            cardno_db = cardno_db.PadRight(18, ".")
                            strd = strd.Replace("CARD NUMBER ·..................", "CARD Number ·" & cardno_db)
                        End If
                        If strd.Contains("EXPIRY DATE  ·") Then
                            expiry_date = expiry_date.Replace("/", "").Trim
                            strd = strd.Replace("EXPIRY DATE  ·....", "EXPIRY DATE  ·" & expiry_date)
                        End If
                        If strd.Contains("REFUND AMOUNT ·.........") Then
                            If ticket_type = "expired" Then
                                refund_amt = refund_amt.PadRight(9, ".")
                                strd = strd.Replace("REFUND AMOUNT ·.........", "REFUND AMOUNT ·" & refund_amt)
                            End If
                        End If
                    End If
                    '''''credit card details'''''

                    ddf2.Add(strd.PadRight(&H40, " "c))
                Next
                Dim str = Strings.Join(ddf2.ToArray, "")
                con.MakeEntry("<FORMAT>" & str & "</FORMAT>") 'will refund amount
                log(str)
                log(con.ResponseXML)

                If refund_remarks <> "" Then
                    If con.ResponseXML.Contains("TRN3") And con.ResponseXML.Contains("REFUND DUE") And con.ResponseXML.Contains("FOURTH MIR FREETEXT SCREEN Y/N") Then
                        Dim ddf1 As New ArrayList
                        Dim strd1 As String = ""
                        For i = 0 To con.NumResponseLines - 1
                            strd1 = con.ResponseLine(i).Replace("<CARRIAGE_RETURN/>", "").Replace("<TABSTOP/>", ChrW(183)).Replace("<SOM/>", " ")
                            If strd1.Contains("REMARKS ") Then
                                Dim acr As String = ""
                                For li = 0 To refund_remarks.Length - 1
                                    acr = acr & "."
                                Next
                                strd1 = strd1.Replace("REMARKS ·" & acr, "REMARKS ·" & refund_remarks)
                            End If

                            If strd1.Contains("FOURTH MIR FREETEXT SCREEN Y/N ·.") Then
                                strd1 = strd1.Replace("FOURTH MIR FREETEXT SCREEN Y/N ·.", "FOURTH MIR FREETEXT SCREEN Y/N ·N")
                            End If

                            ddf1.Add(strd1.PadRight(&H40, " "c))
                        Next
                        Dim str1 = Strings.Join(ddf1.ToArray, "")
                        con.MakeEntry("<FORMAT>" & str1 & "</FORMAT>") 'will refund amount
                        log(str1)
                        log(con.ResponseXML)
                    End If
                Else
                    log("Third screen")
                    Dim ddf As New ArrayList
                    strd = ""
                    Dim total_credit_rfnd As String = 0
                    Dim rf_up_bool As Boolean = False
                    If cc_fop_bool = True Then
                        log("FOP is CC.")
                        If InStr(con.ResponseXML, "TOTAL CREDIT REFUND DUE") Then
                            For b As Integer = 0 To con.NumResponseLines - 1
                                If InStr(con.ResponseLine(b).ToString, "TOTAL CREDIT REFUND DUE") Then
                                    total_credit_rfnd = con.ResponseLine(b).ToString.Replace("TOTAL CREDIT REFUND DUE", "").Replace("<CARRIAGE_RETURN/>", "").Trim
                                    log("Total Credit refund: " & total_credit_rfnd)
                                    If IsNumeric(total_credit_rfnd) Then
                                    Else
                                        log("Total credit amount is not valid")
                                        Return "Failed"
                                    End If
                                End If
                            Next
                        Else
                            log("Total credit fop not present")
                            Return "Failed"
                        End If
                    End If

                    For i = 0 To con.NumResponseLines - 1
                        strd = con.ResponseLine(i).Replace("<CARRIAGE_RETURN/>", "").Replace("<TABSTOP/>", ChrW(183)).Replace("<SOM/>", " ")
                        If strd.Contains("THIRD SCREEN Y/N ·.") Then
                            strd = strd.Replace("THIRD SCREEN Y/N ·.", "THIRD SCREEN Y/N ·N")
                        End If

                        If strd.Contains("FOURTH MIR FREETEXT SCREEN Y/N ·.") Then
                            strd = strd.Replace("FOURTH MIR FREETEXT SCREEN Y/N ·.", "FOURTH MIR FREETEXT SCREEN Y/N ·N")
                        End If

                        If strd.Contains("REFUND AMOUNT ·") AndAlso strd.Contains("EXPIRY DATE ") Then
                            If cc_fop_bool = True AndAlso rf_up_bool = False Then
                                rf_up_bool = True
                                Dim acr As String = total_credit_rfnd
                                acr = acr.PadRight(9, ".")
                                strd = strd.Replace("REFUND AMOUNT ·.........", "REFUND AMOUNT ·" & acr)
                            End If
                        End If
                        ddf.Add(strd.PadRight(&H40, " "c))
                    Next

                    str = ""
                    str = Strings.Join(ddf.ToArray, "")
                    con.MakeEntry("<FORMAT>" & str & "</FORMAT>") 'will refund amount
                    log(str)
                    log(con.ResponseXML)

                    If con.ResponseXML.Contains("TRN3") AndAlso con.ResponseXML.Contains("REFUND DUE") AndAlso con.ResponseXML.Contains("FOURTH MIR FREETEXT SCREEN Y/N") Then
                        log("TRN3 & FOURTH MIR SCREEN")
                        Dim ddf1 As New ArrayList
                        Dim strd1 As String = ""
                        For i = 0 To con.NumResponseLines - 1
                            strd1 = con.ResponseLine(i).Replace("<CARRIAGE_RETURN/>", "").Replace("<TABSTOP/>", ChrW(183)).Replace("<SOM/>", " ")
                            If strd1.Contains("REMARKS ") Then
                                If refund_remarks <> "" Then
                                    Dim acr As String = ""
                                    For li = 0 To refund_remarks.Length - 1
                                        acr = acr & "."
                                    Next
                                    strd1 = strd1.Replace("REMARKS ·" & acr, "REMARKS ·" & refund_remarks)
                                End If
                            End If

                            If strd1.Contains("FOURTH MIR FREETEXT SCREEN Y/N ·.") Then
                                strd1 = strd1.Replace("FOURTH MIR FREETEXT SCREEN Y/N ·.", "FOURTH MIR FREETEXT SCREEN Y/N ·N")
                            End If
                            ddf1.Add(strd1.PadRight(&H40, " "c))
                        Next
                        Dim str1 = Strings.Join(ddf1.ToArray, "")
                        con.MakeEntry("<FORMAT>" & str1 & "</FORMAT>") 'will refund amount
                        log(str1)
                        log(con.ResponseXML)
                    End If
                End If

                If con.ResponseXML.Contains("PRINTER DOWN/BUSY") And Checked = False Then

                    con.MakeEntry("<FORMAT>HMLD</FORMAT>")
                    log("HMLD")
                    log(con.ResponseXML)

                    con.MakeEntry("<FORMAT>HMET</FORMAT>")
                    log("HMET")
                    log(con.ResponseXML)

                    Dim GTID As String = ""
                    Dim str1 As String = ""
                    For i = 0 To con.NumResponseLines - 1
                        str1 = str1 & vbLf & con.ResponseLine(i).ToString
                    Next
                    log(str1)

                    Dim gtary As Array = Nothing
                    For i = 0 To con.NumResponseLines - 1
                        If con.ResponseLine(i).Contains("RFND NOTC") Then
                            gtary = Split(con.ResponseLine(i).ToString.Trim, "<TABSTOP/>")
                            GTID = gtary(1).ToString.Trim.Substring(0, 6)
                            Exit For
                        End If
                    Next

                    If GTID = "" Then
                        gtary = Nothing
                        For i = 0 To con.NumResponseLines - 1
                            If con.ResponseLine(i).Contains("AGENT CPN") Then
                                gtary = Split(con.ResponseLine(i).ToString.Trim, "<TABSTOP/>")
                                GTID = gtary(1).ToString.Trim.Substring(0, 6)
                                Exit For
                            End If
                        Next
                    End If

                    log("GTID taken: " & GTID)
                    If GTID <> "" Then
                        Dim nxtEntry = "HMLM" & GTID & "DT/" & GTID & "DI"
                        con.MakeEntry("<FORMAT>" & nxtEntry & "</FORMAT>")
                        log(nxtEntry)
                        log(con.ResponseXML)

                        con.MakeEntry("<FORMAT>HMOM" & GTID & "-U</FORMAT>")
                        log("HMOM" & GTID & "-U")
                        log(con.ResponseXML)
                    End If

                    If con.ResponseXML.Contains("NOW UP") Then
                        Checked = True
                        GoTo Process
                    End If
                Else
                    strd = ""
                    For i = 0 To con.NumResponseLines - 1
                        strd = con.ResponseLine(i).Replace("<CARRIAGE_RETURN/>", "").Replace("<TABSTOP/>", ChrW(183)).Replace("<SOM/>", " ")
                        If strd.Contains("CASH REFUND AMOUNT") Then
                            customerRefAmt = strd.Replace("CASH REFUND AMOUNT", "").Trim
                            Exit For
                        ElseIf strd.Contains("CREDIT CARD") AndAlso strd.Contains("AMOUNT ") Then
                            log("CREDIT card refund")
                            customerRefAmt = strd
                            Dim ary As Array = Split(customerRefAmt, "AMOUNT")
                            customerRefAmt = ary(1).ToString.Trim
                            log("Refund amount credit: " & customerRefAmt)
                            Exit For
                        End If
                    Next
                End If

            End If

        Catch ex As Exception
            Return "Failed"
        End Try
        Return customerRefAmt
    End Function

    Function convertHistoryXML(ByVal text As String) As String

        Dim k = 0
        Dim l = 0
        Dim i = 0
        Dim j = 0
        Dim resultstr = ""
        Dim ab = ""
        Dim ac = ""
        Dim valu = ""
        Dim TktRespAry = text.Split(vbLf)
        For kl As Integer = 0 To TktRespAry.Length - 1
            If TktRespAry(kl).Length > 10 Then
                If InStr(TktRespAry(kl), "CRDT-") Then
                    l = l + 1
                    resultstr = resultstr & "<action id=" & Chr(34) & TktRespAry(kl) & Chr(34) & " seq=" & Chr(34) & l & Chr(34) & ">" & valu & "</action>"
                    valu = ""
                Else
                    If InStr(TktRespAry(kl), "<CARRIAGE_RETURN/>") Then
                        ab = "@" & Replace(TktRespAry(kl), "<CARRIAGE_RETURN/>", "")
                    Else
                        ab = "@" & TktRespAry(kl)
                        If InStr(ab, "@ SC") Or InStr(ab, "@ SX") Or InStr(ab, "@ SA") Or InStr(ab, "@HSD") Then

                            ab = "@" & TktRespAry(kl)

                        Else
                            ab = "@" & TktRespAry(kl) & Replace(TktRespAry(kl + 1), "<CARRIAGE_RETURN/>", "")
                            j = j + 1
                        End If
                    End If

                    ab = Replace(ab, ")<SOM/>", "")
                    ab = Replace(ab, "<SOM/>", "")
                    ab = Replace(ab, "<TABSTOP/>", "")
                    ab = Replace(ab, "<PILLOW/>", "//")
                    If InStr(ab, "@HS ") Or InStr(ab, "@SC ") Or InStr(ab, "@XS ") Or InStr(ab, "@AS ") Or InStr(ab, "@VLR") Then
                        If (ab.Substring(4, 3)) = "CCR" Then
                            k = k + 1
                            valu = valu & "<ACTIONITEM>"
                            valu = valu & "<TYPE>CARPASS</TYPE>"
                            valu = valu & "<SEQUENCE>" & k & "</SEQUENCE>"
                            valu = valu & "<ACTIONCOMMIT>" & Trim(ab.Substring(0, 4)) & "</ACTIONCOMMIT>"
                            valu = valu & "<CARV>" & ab.Substring(8, 2) & "</CARV>"
                            valu = valu & "<DOJ>" & ab.Substring(11, 5) & "</DOJ>"
                            valu = valu & "<STATUS>" & ab.Substring(17, 7) & "</STATUS>"
                            valu = valu & "<ORIGIN>" & ab.Substring(25, 3) & "</ORIGIN>"
                            valu = valu & "<DOE>" & ab.Substring(30, 5) & "</DOE>"
                            valu = valu & "<CARTYPE>" & ab.Substring(36, 4) & "</CARTYPE>"
                            valu = valu & "</ACTIONITEM>"
                            valu = valu & "<ACTIONITEM id=" & Chr(34) & k & Chr(34) & "><TEXT>" & ab.Substring(41, ab.Length - 41) & "</TEXT></ACTIONITEM>"

                        ElseIf (ab.Substring(4, 3)) = "CAR" Then
                            k = k + 1
                            valu = valu & "<ACTIONITEM>"
                            valu = valu & "<TYPE>CARSEG</TYPE>"
                            valu = valu & "<SEQUENCE>" & k & "</SEQUENCE>"
                            valu = valu & "<ACTIONCOMMIT>" & Trim(ab.Substring(0, 4)) & "</ACTIONCOMMIT>"
                            valu = valu & "<CARV>" & ab.Substring(8, 2) & "</CARV>"
                            valu = valu & "<DOJ>" & ab.Substring(11, 5) & "</DOJ>"
                            valu = valu & "<STATUS>" & ab.Substring(17, 7) & "</STATUS>"
                            valu = valu & "<ORIGIN>" & ab.Substring(25, 3) & "</ORIGIN>"
                            valu = valu & "<DOE>" & ab.Substring(30, 5) & "</DOE>"
                            valu = valu & "<CARTYPE>" & ab.Substring(35, 4) & "</CARTYPE>"
                            valu = valu & "</ACTIONITEM>"
                            valu = valu & "<ACTIONITEM id=" & Chr(34) & k & Chr(34) & "><TEXT>" & ab.Substring(40, ab.Length - 40) & "</TEXT></ACTIONITEM>"

                        ElseIf (ab.Substring(4, 3)) = "ATX" Then
                            k = k + 1
                            valu = valu & "<ACTIONITEM>"
                            valu = valu & "<TYPE>ATXSEG</TYPE>"
                            valu = valu & "<SEQUENCE>" & k & "</SEQUENCE>"
                            valu = valu & "<ACTIONCOMMIT>" & Trim(ab.Substring(0, 4)) & "</ACTIONCOMMIT>"
                            valu = valu & "<ATXV>" & ab.Substring(8, 2) & "</ATXV>"
                            valu = valu & "<DOJ>" & ab.Substring(11, 5) & "</DOJ>"
                            valu = valu & "<STATUS>" & ab.Substring(17, 7) & "</STATUS>"
                            valu = valu & "<ORIGIN>" & ab.Substring(25, 3) & "</ORIGIN>"
                            valu = valu & "</ACTIONITEM>"
                            valu = valu & "<ACTIONITEM id=" & Chr(34) & k & Chr(34) & "><TEXT>" & ab.Substring(30, ab.Length - 30) & "</TEXT></ACTIONITEM>"
                        ElseIf (ab.Substring(4, 3)) = "SUR" Then
                            k = k + 1
                            valu = valu & "<ACTIONITEM>"
                            valu = valu & "<TYPE>SURSEG</TYPE>"
                            valu = valu & "<SEQUENCE>" & k & "</SEQUENCE>"
                            valu = valu & "<ACTIONCOMMIT>" & Trim(ab.Substring(0, 4)) & "</ACTIONCOMMIT>"
                            valu = valu & "<SURV>" & ab.Substring(8, 2) & "</SURV>"
                            valu = valu & "<DOJ>" & ab.Substring(11, 5) & "</DOJ>"
                            valu = valu & "<STATUS>" & ab.Substring(17, 7) & "</STATUS>"
                            valu = valu & "<ORIGIN>" & ab.Substring(25, 3) & "</ORIGIN>"
                            valu = valu & "</ACTIONITEM>"
                            valu = valu & "<ACTIONITEM id=" & Chr(34) & k & Chr(34) & "><TEXT>" & ab.Substring(30, ab.Length - 30) & "</TEXT></ACTIONITEM>"
                        ElseIf (ab.Substring(4, 3)) = "HTL" Then
                            k = k + 1
                            valu = valu & "<ACTIONITEM>"
                            valu = valu & "<TYPE>HTLPASS</TYPE>"
                            valu = valu & "<SEQUENCE>" & k & "</SEQUENCE>"
                            valu = valu & "<ACTIONCOMMIT>" & Trim(ab.Substring(0, 4)) & "</ACTIONCOMMIT>"
                            valu = valu & "<HTLV>" & ab.Substring(8, 2) & "</HTLV>"
                            valu = valu & "<DOJ>" & ab.Substring(11, 5) & "</DOJ>"
                            valu = valu & "<STATUS>" & ab.Substring(17, 7) & "</STATUS>"
                            valu = valu & "<ORIGIN>" & ab.Substring(25, 3) & "</ORIGIN>"
                            valu = valu & "<DOE>" & ab.Substring(33, 5) & "</DOE>"
                            ' valu = valu & "<CARTYPE>" & ab.Substring(36, 4) & "</CARTYPE>"
                            valu = valu & "</ACTIONITEM>"
                            valu = valu & "<ACTIONITEM id=" & Chr(34) & k & Chr(34) & "><TEXT>" & ab.Substring(41, ab.Length - 41) & "</TEXT></ACTIONITEM>"
                        ElseIf (ab.Substring(4, 3)) = "HHL" Then
                            k = k + 1
                            valu = valu & "<ACTIONITEM>"
                            valu = valu & "<TYPE>HTLSEG</TYPE>"
                            valu = valu & "<SEQUENCE>" & k & "</SEQUENCE>"
                            valu = valu & "<ACTIONCOMMIT>" & Trim(ab.Substring(0, 4)) & "</ACTIONCOMMIT>"
                            valu = valu & "<HTLV>" & ab.Substring(8, 2) & "</HTLV>"
                            valu = valu & "<DOJ>" & ab.Substring(11, 5) & "</DOJ>"
                            valu = valu & "<STATUS>" & ab.Substring(17, 7) & "</STATUS>"
                            valu = valu & "<ORIGIN>" & ab.Substring(25, 3) & "</ORIGIN>"
                            valu = valu & "<DOE>" & ab.Substring(30, 5) & "</DOE>"
                            valu = valu & "<DURATION>" & ab.Substring(36, 4) & "</DURATION>"
                            valu = valu & "<ROOMID>" & ab.Substring(40, 6) & "</ROOMID>"

                            valu = valu & "</ACTIONITEM>"
                            valu = valu & "<ACTIONITEM id=" & Chr(34) & k & Chr(34) & "><TEXT>" & ab.Substring(46, ab.Length - 46) & "</TEXT></ACTIONITEM>"
                        ElseIf (ab.Substring(4, 3)) = "TUR" Then
                            k = k + 1
                            valu = valu & "<ACTIONITEM>"
                            valu = valu & "<TYPE>TURSEG</TYPE>"
                            valu = valu & "<SEQUENCE>" & k & "</SEQUENCE>"
                            valu = valu & "<ACTIONCOMMIT>" & Trim(ab.Substring(0, 4)) & "</ACTIONCOMMIT>"
                            valu = valu & "<TURV>" & ab.Substring(8, 2) & "</TURV>"
                            valu = valu & "<DOJ>" & ab.Substring(11, 5) & "</DOJ>"
                            valu = valu & "<STATUS>" & ab.Substring(17, 7) & "</STATUS>"
                            valu = valu & "<ORIGIN>" & ab.Substring(25, 3) & "</ORIGIN>"

                            valu = valu & "</ACTIONITEM>"
                            valu = valu & "<ACTIONITEM id=" & Chr(34) & k & Chr(34) & "><TEXT>" & ab.Substring(30, ab.Length - 30) & "</TEXT></ACTIONITEM>"
                        ElseIf (ab.Substring(6, 4)) = "OPEN" Then
                            k = k + 1
                            valu = valu & "<ACTIONITEM>"
                            valu = valu & "<TYPE>OPENSEG</TYPE>"
                            valu = valu & "<SEQUENCE>" & k & "</SEQUENCE>"
                            valu = valu & "<ACTIONCOMMIT>" & Trim(ab.Substring(0, 4)) & "</ACTIONCOMMIT>"
                            If InStr(ab, "@VLR") Then
                                valu = valu & "<AIRV>" & ab.Substring(5, 2) & "</AIRV>"
                                valu = valu & "<FLTNO>" & ab.Substring(7, 4) & "</FLTNO>"
                                valu = valu & "<CLASS>" & ab.Substring(12, 1) & "</CLASS>"
                                valu = valu & "<DOJ>" & ab.Substring(14, 5) & "</DOJ>"
                                valu = valu & "<ORIGIN>" & ab.Substring(20, 3) & "</ORIGIN>"
                                valu = valu & "<DESTINATION>" & ab.Substring(23, 3) & "</DESTINATION>"
                                valu = valu & "<STATUS>" & ab.Substring(27, ab.Length - 27) & "</STATUS>"

                            Else

                                valu = valu & "<AIRV>" & ab.Substring(4, 2) & "</AIRV>"
                                valu = valu & "<FLTNO>" & ab.Substring(6, 4) & "</FLTNO>"
                                valu = valu & "<CLASS>" & ab.Substring(11, 1) & "</CLASS>"
                                valu = valu & "<DOJ>" & ab.Substring(13, 5) & "</DOJ>"
                                valu = valu & "<ORIGIN>" & ab.Substring(19, 3) & "</ORIGIN>"
                                valu = valu & "<DESTINATION>" & ab.Substring(22, 3) & "</DESTINATION>"
                                valu = valu & "<STATUS>" & ab.Substring(26, ab.Length - 26) & "</STATUS>"

                            End If
                            valu = valu & "</ACTIONITEM>"
                        Else
                            ac = Trim(ab.Substring(4, 3))
                            If ac.Length = 2 Then
                                k = k + 1
                                valu = valu & "<ACTIONITEM>"
                                valu = valu & "<TYPE>AIRSEG</TYPE>"
                                valu = valu & "<SEQUENCE>" & k & "</SEQUENCE>"
                                valu = valu & "<ACTIONCOMMIT>" & Trim(ab.Substring(0, 4)) & "</ACTIONCOMMIT>"
                                If InStr(ab, "@VLR") Then
                                    valu = valu & "<AIRV>" & ab.Substring(5, 2) & "</AIRV>"
                                    valu = valu & "<FLTNO>" & ab.Substring(7, 4) & "</FLTNO>"
                                    valu = valu & "<CLASS>" & ab.Substring(12, 1) & "</CLASS>"
                                    valu = valu & "<DOJ>" & ab.Substring(14, 5) & "</DOJ>"
                                    valu = valu & "<ORIGIN>" & ab.Substring(20, 3) & "</ORIGIN>"
                                    valu = valu & "<DESTINATION>" & ab.Substring(23, 3) & "</DESTINATION>"
                                    valu = valu & "<STATUS>" & ab.Substring(27, 7) & "</STATUS>"
                                    valu = valu & "<DEP>" & ab.Substring(35, 5) & "</DEP>"
                                    valu = valu & "<ARR>" & ab.Substring(41, 5) & "</ARR>"
                                    valu = valu & "<SELIND>" & ab.Substring(47, 2) & "</SELIND>"

                                Else

                                    valu = valu & "<AIRV>" & ab.Substring(4, 2) & "</AIRV>"
                                    valu = valu & "<FLTNO>" & ab.Substring(6, 4) & "</FLTNO>"
                                    valu = valu & "<CLASS>" & ab.Substring(11, 1) & "</CLASS>"
                                    valu = valu & "<DOJ>" & ab.Substring(13, 5) & "</DOJ>"
                                    valu = valu & "<ORIGIN>" & ab.Substring(19, 3) & "</ORIGIN>"
                                    valu = valu & "<DESTINATION>" & ab.Substring(22, 3) & "</DESTINATION>"
                                    valu = valu & "<STATUS>" & ab.Substring(26, 6) & "</STATUS>"
                                    If ab.Length <= 36 Then
                                    Else
                                        valu = valu & "<DEP>" & ab.Substring(34, 5) & "</DEP>"
                                        If InStr(ab.Substring(26, 7), "AK") Or InStr(ab.Substring(26, 7), "BK") Then
                                            valu = valu & "<ARR>" & ab.Substring(40, 4) & "</ARR>"
                                        Else
                                            If ab.Length < 42 Then
                                            Else
                                                If ab.Length <= 44 Then
                                                    valu = valu & "<ARR>" & ab.Substring(40, 4) & "</ARR>"
                                                Else
                                                    valu = valu & "<ARR>" & ab.Substring(40, 5) & "</ARR>"

                                                    ' valu = valu & "<ARR>" & ab.Substring(40, 5) & "</ARR>"

                                                    If ab.Length = 45 Then


                                                    ElseIf ab.Length - 2 <= 46 Then
                                                        valu = valu & "<SELIND>" & ab.Substring(46, 1) & "</SELIND>"
                                                    Else

                                                        valu = valu & "<SELIND>" & ab.Substring(46, 2) & "</SELIND>"
                                                    End If
                                                End If
                                            End If
                                        End If
                                    End If


                                End If
                                valu = valu & "</ACTIONITEM>"
                            ElseIf ac.Length = 1 Then

                            ElseIf ac.Length = 3 Then
                                k = k + 1
                                valu = valu & "<ACTIONITEM>"
                                valu = valu & "<TYPE>AIRSEG</TYPE>"
                                valu = valu & "<SEQUENCE>" & k & "</SEQUENCE>"
                                valu = valu & "<ACTIONCOMMIT>" & Trim(ab.Substring(0, 4)) & "</ACTIONCOMMIT>"
                                If InStr(ab, "@VLR") Then
                                    valu = valu & "<AIRV>" & ab.Substring(5, 2) & "</AIRV>"
                                    valu = valu & "<FLTNO>" & ab.Substring(7, 4) & "</FLTNO>"
                                    valu = valu & "<CLASS>" & ab.Substring(12, 1) & "</CLASS>"
                                    valu = valu & "<DOJ>" & ab.Substring(14, 5) & "</DOJ>"
                                    valu = valu & "<ORIGIN>" & ab.Substring(20, 3) & "</ORIGIN>"
                                    valu = valu & "<DESTINATION>" & ab.Substring(23, 3) & "</DESTINATION>"
                                    valu = valu & "<STATUS>" & ab.Substring(27, 7) & "</STATUS>"
                                    valu = valu & "<DEP>" & ab.Substring(35, 5) & "</DEP>"
                                    valu = valu & "<ARR>" & ab.Substring(41, 5) & "</ARR>"
                                    valu = valu & "<SELIND>" & ab.Substring(47, 2) & "</SELIND>"

                                Else
                                    valu = valu & "<AIRV>" & ab.Substring(4, 2) & "</AIRV>"
                                    valu = valu & "<FLTNO>" & ab.Substring(6, 4) & "</FLTNO>"
                                    valu = valu & "<CLASS>" & ab.Substring(11, 1) & "</CLASS>"
                                    valu = valu & "<DOJ>" & ab.Substring(13, 5) & "</DOJ>"
                                    valu = valu & "<ORIGIN>" & ab.Substring(19, 3) & "</ORIGIN>"
                                    valu = valu & "<DESTINATION>" & ab.Substring(22, 3) & "</DESTINATION>"
                                    valu = valu & "<STATUS>" & ab.Substring(26, 6) & "</STATUS>"
                                    If ab.Length <= 36 Then
                                    Else
                                        valu = valu & "<DEP>" & ab.Substring(34, 5) & "</DEP>"
                                        If InStr(ab.Substring(26, 7), "AK") Or InStr(ab.Substring(26, 7), "BK") Then
                                            valu = valu & "<ARR>" & ab.Substring(40, 4) & "</ARR>"
                                        Else
                                            If ab.Length < 42 Then
                                            Else
                                                If ab.Length <= 44 Then
                                                    valu = valu & "<ARR>" & ab.Substring(40, 4) & "</ARR>"
                                                Else

                                                    valu = valu & "<ARR>" & ab.Substring(40, 5) & "</ARR>"

                                                    If ab.Length = 45 Then

                                                    ElseIf ab.Length - 2 <= 46 Then

                                                        valu = valu & "<SELIND>" & ab.Substring(46, 1) & "</SELIND>"
                                                    Else

                                                        valu = valu & "<SELIND>" & ab.Substring(46, 2) & "</SELIND>"
                                                    End If
                                                End If
                                            End If
                                        End If
                                    End If

                                End If
                                valu = valu & "</ACTIONITEM>"
                            End If

                        End If
                    Else
                        If ab.Length > 2 Then
                            If ab.Substring(1, 3) = "   " Then
                                valu = valu & "<ACTIONITEM id=" & Chr(34) & k & Chr(34) & "><TEXT>" & ab.Substring(4, ab.Length - 4) & "</TEXT></ACTIONITEM>"
                            Else
                                If ab.Substring(1, 1) = "?" Then
                                    valu = valu & "<ACTIONITEM><ACTIONCOMMIT>" & ab.Substring(0, 2) & "</ACTIONCOMMIT><TEXT>" & ab.Substring(2, ab.Length - 2) & "</TEXT></ACTIONITEM>"
                                ElseIf InStr(ab, "RCVD-") Then
                                    valu = valu & "<ACTIONITEM><ACTIONCOMMIT>" & ab.Substring(0, 5) & "</ACTIONCOMMIT><TEXT>" & ab.Substring(6, ab.Length - 6) & "</TEXT></ACTIONITEM>"
                                ElseIf ab.Substring(0, 4) = "@* S" Then
                                    k = k + 1
                                    valu = valu & "<ACTIONITEM><ACTIONCOMMIT>" & ab & "</ACTIONCOMMIT><SEQUENCE>" & k & "</SEQUENCE></ACTIONITEM>"
                                Else
                                    k = k + 1
                                    valu = valu & "<ACTIONITEM><ACTIONCOMMIT>" & ab.Substring(0, 4) & "</ACTIONCOMMIT><TEXT>" & ab.Substring(4, ab.Length - 4) & "</TEXT><SEQUENCE>" & k & "</SEQUENCE></ACTIONITEM>"
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        Next
        Dim dd = Format(Date.Now, "dd/MMM/yyyy - hh:mm:ss tt")
        resultstr = Replace(resultstr, "<CARRIAGE_RETURN/>", "")
        resultstr = "<History dat=" & Chr(34) & dd & Chr(34) & ">" & resultstr & "</History>"
        'resultstr = Replace(resultstr, "@AA", "Added related address field ")
        'resultstr = Replace(resultstr, "@AB", "Added purchased field ")
        'resultstr = Replace(resultstr, "@ACI", "Added customer ID field ")
        'resultstr = Replace(resultstr, "@ACD", "Added abonnement card details ")
        'resultstr = Replace(resultstr, "@AC", "Added action field ")
        'resultstr = Replace(resultstr, "@AES", "Added estimated total data -carhire and hotels ")
        'resultstr = Replace(resultstr, "@AFB", "Added manual fare quote ")
        'resultstr = Replace(resultstr, "@AFQ", "Fare quote at time of ticketing ")
        'resultstr = Replace(resultstr, "@AG", "Added SSR ")
        'resultstr = Replace(resultstr, "@AI", "Added special remarks field ")
        'resultstr = Replace(resultstr, "@AMC", "Added mileage membership cross accrual data ")
        'resultstr = Replace(resultstr, "@AMT", "Added mail to")
        'resultstr = Replace(resultstr, "@AM", "Added mileage membership number")
        'resultstr = Replace(resultstr, "@AN", "Added name ")
        'resultstr = Replace(resultstr, "@AO", "Added OSI ")
        'resultstr = Replace(resultstr, "@APQ", "Enhanced booking file service request added to PCC queue ")
        'resultstr = Replace(resultstr, "@AP", "Added TOD MCO number ")
        'resultstr = Replace(resultstr, "@AQP", "Added to queue trail on an agents programmatic queue ")
        'resultstr = Replace(resultstr, "@AQT", "Added to current tau queue placement ")
        'resultstr = Replace(resultstr, "@AQ", "Added to queue trail ")
        'resultstr = Replace(resultstr, "@ARQ", "Added enhanced booking file service request ")
        'resultstr = Replace(resultstr, "@AR", "Added to routing field ")
        'resultstr = Replace(resultstr, "@AS", "Added segment ")
        'resultstr = Replace(resultstr, "@AT", "Modifiers added at ticket issue ")
        'resultstr = Replace(resultstr, "@AVI", "Added incoming vendor remark ")
        'resultstr = Replace(resultstr, "@AVL", "Added vendor locator ")
        'resultstr = Replace(resultstr, "@AVO", "Added outgoing vendor remark ")
        'resultstr = Replace(resultstr, "@AW", "Added written address field or subfield ")
        'resultstr = Replace(resultstr, "@CF", "Added confirmation number (hotel, car) ")
        'resultstr = Replace(resultstr, "@CG", "Changed SSR ")
        'resultstr = Replace(resultstr, "@CNP", "Changed notepad (when optional Historical indicator was used) ")
        'resultstr = Replace(resultstr, "@CO", "Changed OSI ")
        'resultstr = Replace(resultstr, "@CS", "Changed hotel segment optional data ")
        'resultstr = Replace(resultstr, "@DN", "Divided name ")
        'resultstr = Replace(resultstr, "@DRQ", "Deleted enhanced booking file service request ")
        'resultstr = Replace(resultstr, "@DVI", "Deleted incoming vendor remark ")
        'resultstr = Replace(resultstr, "@DVO", "Deleted outgoing vendor remark ")
        'resultstr = Replace(resultstr, "@DA", "Data added ")
        'resultstr = Replace(resultstr, "@DM", "Data modified ")
        'resultstr = Replace(resultstr, "@DO", "Data originator ")
        'resultstr = Replace(resultstr, "@DR", "Reinstated client file ")
        'resultstr = Replace(resultstr, "@DU", "Dynamic update request ")
        'resultstr = Replace(resultstr, "@DX", "Data deleted ")
        'resultstr = Replace(resultstr, "@FP", "Changed or deleted form of payment ")
        'resultstr = Replace(resultstr, "@HSD", "Denoted flight for which historical seat data exists")
        'resultstr = Replace(resultstr, "@HS", "Original segment status ")
        'resultstr = Replace(resultstr, "@IG", "Service information via incoming teletype ")
        'resultstr = Replace(resultstr, "@OG", "Service information via outgoing teletype ")
        'resultstr = Replace(resultstr, "@ SA", "Added seat (preceded by HSD) ")
        'resultstr = Replace(resultstr, "@SC", "Segment status change ")
        'resultstr = Replace(resultstr, "@ SC", "Changed seat status (preceded by HSD) ")
        'resultstr = Replace(resultstr, "@ SX", "Deleted seat (preceded by HSD) ")
        'resultstr = Replace(resultstr, "@VLR", "Vendor locator reference ")
        'resultstr = Replace(resultstr, "@XCI", "Cancelled customer ID field ")
        'resultstr = Replace(resultstr, "@XCD", "Cancelled abonnement card details field ")
        'resultstr = Replace(resultstr, "@XC", "Changed action field ")
        'resultstr = Replace(resultstr, "@XES", "Deleted estimated total data - carhire and hotel ")
        'resultstr = Replace(resultstr, "@XFB", "Deleted manual fare ")
        'resultstr = Replace(resultstr, "@XFQ", "Deleted fare quote ")
        'resultstr = Replace(resultstr, "@XG", "Deleted or cancelled SSR ")
        'resultstr = Replace(resultstr, "@XA", "Deleted related address field ")
        'resultstr = Replace(resultstr, "@XI", "Changed fare field ")
        'resultstr = Replace(resultstr, "@XK", "Replace TINS ")
        'resultstr = Replace(resultstr, "@XMC", "Deleted mileage membership cross accrual data ")
        'resultstr = Replace(resultstr, "@XM", "Deleted mileage membership number ")
        'resultstr = Replace(resultstr, "@XNP", "Cancelled notepad (when optional Historical indicator was used) ")
        'resultstr = Replace(resultstr, "@XN", "Changed or deleted name ")
        'resultstr = Replace(resultstr, "@XO", "Changed or deleted OSI ")
        'resultstr = Replace(resultstr, "@XP", "Changed or deleted phone ")
        'resultstr = Replace(resultstr, "@XQ", "Removed from queue ")
        'resultstr = Replace(resultstr, "@XRB", "Cancelled review booking file field ")
        'resultstr = Replace(resultstr, "@XRQ", "Cancelled enhanced booking file service request ")
        'resultstr = Replace(resultstr, "@XR", "Changed routing field ")
        'resultstr = Replace(resultstr, "@XS", "Cancelled segment ")
        'resultstr = Replace(resultstr, "@XT", "Changed or deleted ticket arrangement field ")
        'resultstr = Replace(resultstr, "@XW", "Changed or deleted written address field or subfield ")
        resultstr = Replace(resultstr, "<CARRIAGE_RETURN/>", "")
        resultstr = Replace(resultstr, ")<SOM/>", "")
        resultstr = Replace(resultstr, "<SOM/>", "")
        resultstr = Replace(resultstr, "<TABSTOP/>", "")
        resultstr = Replace(resultstr, "@", "")
        Return resultstr
    End Function

    Public Function lic_Decrypt(ByVal cipherText As String) As String

        Dim passPhrase As String = "licpassphrase"
        Dim saltValue As String = "LicenseDate"
        Dim hashAlgorithm As String = "SHA1"

        Dim passwordIterations As Integer = 2
        Dim initVector As String = "@1B2c3D4e5F6g7H8"
        Dim keySize As Integer = 256
        Dim initVectorBytes As Byte() = Encoding.ASCII.GetBytes(initVector)
        Dim saltValueBytes As Byte() = Encoding.ASCII.GetBytes(saltValue)
        Dim cipherTextBytes As Byte() = Convert.FromBase64String(cipherText)
        Dim password As New PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations)
        Dim keyBytes As Byte() = password.GetBytes(keySize \ 8)
        Dim symmetricKey As New RijndaelManaged()
        symmetricKey.Mode = CipherMode.CBC
        Dim decryptor As ICryptoTransform = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes)

        Dim memoryStream As New MemoryStream(cipherTextBytes)
        Dim cryptoStream As New CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read)
        Dim plainTextBytes As Byte() = New Byte(cipherTextBytes.Length - 1) {}
        Dim decryptedByteCount As Integer = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length)
        memoryStream.Close()
        cryptoStream.Close()

        Dim plainText As String = Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount)
        Return plainText
    End Function

    Public Function lic_Encrypt(ByVal plainText As String) As String

        Dim passPhrase As String = "licpassphrase"
        Dim saltValue As String = "LicenseDate"
        Dim hashAlgorithm As String = "SHA1"
        Dim passwordIterations As Integer = 2
        Dim initVector As String = "@1B2c3D4e5F6g7H8"
        Dim keySize As Integer = 256
        Dim initVectorBytes As Byte() = Encoding.ASCII.GetBytes(initVector)
        Dim saltValueBytes As Byte() = Encoding.ASCII.GetBytes(saltValue)
        Dim plainTextBytes As Byte() = Encoding.UTF8.GetBytes(plainText)

        Dim password As New PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations)
        Dim keyBytes As Byte() = password.GetBytes(keySize \ 8)
        Dim symmetricKey As New RijndaelManaged()
        symmetricKey.Mode = CipherMode.CBC
        Dim encryptor As ICryptoTransform = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes)
        Dim memoryStream As New MemoryStream()
        Dim cryptoStream As New CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write)

        cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length)
        cryptoStream.FlushFinalBlock()
        Dim cipherTextBytes As Byte() = memoryStream.ToArray()
        memoryStream.Close()
        cryptoStream.Close()
        Dim cipherText As String = Convert.ToBase64String(cipherTextBytes)
        Return cipherText
    End Function

    Public Sub log_old(ByVal a As String)

        Try
            Dim sb As New System.Text.StringBuilder()
            Dim d As String = Now.Date
            Dim s As String = d.Replace("/", "-")
            Dim text As String = ""
            Dim filename As String = Application.StartupPath & "\Logs\" & s & ".log"
            Dim objwriter As IO.StreamWriter
            If System.IO.File.Exists(filename) = True Then
                objwriter = New IO.StreamWriter(filename, True)
                text = log_Encrypt(Now.DayOfWeek.ToString & "-" & Now.ToString & ":" & a)
                objwriter.WriteLine("^^^^^^^^^^^^^^^^^^^^^")
                objwriter.WriteLine(text)
                objwriter.WriteLine("^^^^^^^^^^^^^^^^^^^^^")
                objwriter.Close()
            Else
                File.Create(filename).Dispose()
                objwriter = New StreamWriter(filename, True)
                text = log_Encrypt(Now.DayOfWeek.ToString & "-" & Now.ToString & ":" & a)
                objwriter.WriteLine("^^^^^^^^^^^^^^^^^^^^^")
                objwriter.Write(text)
                objwriter.WriteLine("^^^^^^^^^^^^^^^^^^^^^")
                objwriter.Write(vbNewLine)
                objwriter.Close()
            End If
        Catch ex As Exception

        End Try

    End Sub

    Public Sub log(ByVal a As String)

        Try
            Dim sb As New System.Text.StringBuilder()
            Dim d As String = Now.Date
            Dim s As String = d.Replace("/", "-")
            Dim text As String = ""
            Dim filename As String = Application.StartupPath & "\Logs\" & s & ".log"
            Dim objwriter As IO.StreamWriter
            If File.Exists(filename) = True Then
                objwriter = New IO.StreamWriter(filename, True)
                text = Now.DayOfWeek.ToString & "-" & Now.ToString & ":" & a
                objwriter.WriteLine(text)
                objwriter.Close()
            Else
                File.Create(filename).Dispose()
                objwriter = New StreamWriter(filename, True)
                text = Now.DayOfWeek.ToString & "-" & Now.ToString & ":" & a
                objwriter.Write(text)
                objwriter.Write(vbNewLine)
                objwriter.Close()
            End If
        Catch ex As Exception

        End Try

    End Sub

    Public Function log_Encrypt(ByVal plainText As String) As String

        Dim passPhrase As String = "LogPassPhrase"
        Dim saltValue As String = "Log"
        Dim hashAlgorithm As String = "SHA1"
        Dim passwordIterations As Integer = 2
        Dim initVector As String = "@1B2c3D4e5F6g7H8"
        Dim keySize As Integer = 256
        Dim initVectorBytes As Byte() = Encoding.ASCII.GetBytes(initVector)
        Dim saltValueBytes As Byte() = Encoding.ASCII.GetBytes(saltValue)
        Dim plainTextBytes As Byte() = Encoding.UTF8.GetBytes(plainText)
        Dim password As New PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations)
        Dim keyBytes As Byte() = password.GetBytes(keySize \ 8)
        Dim symmetricKey As New RijndaelManaged()
        symmetricKey.Mode = CipherMode.CBC
        Dim encryptor As ICryptoTransform = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes)
        Dim memoryStream As New MemoryStream()
        Dim cryptoStream As New CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write)
        cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length)
        cryptoStream.FlushFinalBlock()
        Dim cipherTextBytes As Byte() = memoryStream.ToArray()
        memoryStream.Close()
        cryptoStream.Close()
        Dim cipherText As String = Convert.ToBase64String(cipherTextBytes)
        Return cipherText

    End Function
End Class
